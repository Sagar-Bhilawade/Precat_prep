package dao;

import pojos.Role;
import pojos.User;

import org.apache.commons.io.FileUtils;
import org.hibernate.*;
import static utils.HibernateUtils.getFactory;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User user) {
		// user : NO(not a part L1 cache) , NO(no db rec) , exists in heap : TRANSIENT
		System.out.println("user id before " + user.getUserId());// null
		String mesg = "User registration Failed !!!!!!!!!!!";
		// get Session from SF
		Session session = getFactory().openSession(); // L1 cache is created
		Session session2 = getFactory().openSession(); // L1 cache is created
		System.out.println(session == session2);// false
		// begin tx
		Transaction tx = session.beginTransaction();
		System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// t t
		try {
			System.out.println("Serializable unique id " + session.save(user));
			// user : PERSISTENT (i.e part of L1 cache)
			tx.commit();// session.flush() --> auto dirty checking ---> DML : insert --> to sync up
						// state of L1 cache to that of DB
			mesg = "User registered successfully " + user.getUserId();// not null
			System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// t t
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		} finally {
			if (session != null)
				session.close();// pooled out DB cn rets to the CP(conn pool) n L1 cache is destroyed
		}
		System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// f f
		// user : DETACHED
		return mesg;
	}

	@Override
	public String registerUserWithCurrentSession(User user) {
		// user : NO(not a part L1 cache) , NO(no db rec) , exists in heap : TRANSIENT
		System.out.println("user id before " + user.getUserId());// null
		String mesg = "User registration Failed !!!!!!!!!!!";
		// get Session from SF
		Session session = getFactory().getCurrentSession(); // no existing session => new session created
		Session session2 = getFactory().getCurrentSession(); // existing session obj reted to the caller
		System.out.println(session == session2);// true
		// begin tx
		Transaction tx = session.beginTransaction();
		System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// t t
		try {
			session.persist(user);
			System.out.println("Serializable unique id " + user.getUserId());
			// user : PERSISTENT (i.e part of L1 cache)
			tx.commit();// session.flush() --> auto dirty checking ---> DML : insert --> to sync up
						// state of L1 cache to that of DB
			mesg = "User registered successfully " + user.getUserId();// not null
			System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// f f
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			System.out.println("is open " + session.isOpen() + " is connected " + session.isConnected());// f f
			// re throw the exc to the caller
			throw e;
		} // user : DETACHED
		return mesg;
	}

	@Override
	public User getUserDetailsById(long userId) {
		User user = null;// user : no state
		// get hibernate session from SF
		Session session = getFactory().getCurrentSession();
		// begin Tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.get(User.class, userId);// in case of valid id , user : PERSISTENT
			user = session.get(User.class, userId);
			user = session.get(User.class, userId);
			user = session.get(User.class, userId);
			tx.commit();// using it here explicitly -- for closing session ---> L1 cache is destroyed n
						// db conn rets to poll
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return user;// user : DETACHED
	}

	@Override
	public List<User> getAllUsers() {
		String jpql = "select u from User u";
		List<User> users = null;
		// get hibernate session from SF
		Session session = getFactory().getCurrentSession();
		// begin Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).getResultList();
			// users : List of PERSISTENT entities
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return users;// users : List of DETACHED entities
	}

	@Override
	public List<User> getSelectedUsers(LocalDate start, LocalDate end1, Role userRole) {
		List<User> users = null;
		String jpql = "select u from User u where u.regDate between :strt and :end and u.userRole=:rl";
		// get hibernate session from SF
		Session session = getFactory().getCurrentSession();
		// begin Tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("strt", start).setParameter("end", end1)
					.setParameter("rl", userRole).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return users;
	}

	@Override
	public List<String> getUserNamesByRegDate(LocalDate date) {
		List<String> names = null;
		String jpql = "select u.name from User u where u.regDate > :dt";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			names = session.createQuery(jpql, String.class).setParameter("dt", date).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return names;
	}

	@Override
	public List<User> getSelectedDetailsByRegDate(LocalDate start, LocalDate end) {
		List<User> users = null;
		String jpql = "select new pojos.User(name,regAmount,userRole) from User u where u.regDate between :strt and :end ";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			users = session.createQuery(jpql, User.class).setParameter("strt", start).setParameter("end", end)
					.getResultList();
			// users : list of persistent entities
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return users;// users : list of detached entities
	}

	@Override
	public String changePassword(long userId, String newPassword) {
		String mesg = "Changing password failed!!!!!!!!!!!!!!";
		User user = null;
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			user = session.get(User.class, userId);
			if (user != null) // => valid user id
			{
				// user : PERSISTENT
				user.setPassword(newPassword); // changing the state of persistent entity
				// session.evict(user);//user : DETACHED
				mesg = "changed user password...........";
			}
			tx.commit();// @ commit --> session.flush --> auto dirty chking --> DML : update --> L1
						// cache is destoyed, pooled out db cn rets to the conn pool , session is
						// closed!
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		if (user != null)
			// user : DETACHED
			user.setPassword("9999999999");
		return mesg;
	}

	@Override
	public String applyBulkDiscount(LocalDate date, double discount) {
		String jpql = "update User u set u.regAmount=u.regAmount-:disc where u.regDate<:date";
		String mesg = "Bulk updation failed!!!!!!!!!!!!";
		// get hibernate session from SF
		Session session = getFactory().getCurrentSession();
		// begin Tx
		Transaction tx = session.beginTransaction();
		try {
			int rowCount = session.createQuery(jpql).setParameter("disc", discount).setParameter("date", date)
					.executeUpdate();
			mesg = "Applied discount to " + rowCount + " users....";
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public String deleteUserByEmail(String email) {
		String mesg = "User un subscription failed!!!!!!!!!!";
		String jpql = "select u from User u where u.email=:em";
		// get hibernate session from SF
		Session session = getFactory().getCurrentSession();
		// begin Tx
		Transaction tx = session.beginTransaction();
		try {
			User u = session.createQuery(jpql, User.class).setParameter("em", email).getSingleResult();
			// u : PERSISTENT
			// mark the entity for removal
			session.delete(u);// u : REMOVED (simply marked for removal , not yet gone from L1 cache n DB)
			tx.commit();// hib perform auto dirty chking (session.flush) upon commit --> delete query
						// fired (rec will be deleted from db , L1 cache destroyed(entity removed from
						// l1 cache) --->TRANSIENT
			mesg = "User with id " + u.getUserId() + " un subscribed....";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return mesg;
	}// u : marked for GC

	@Override
	public String saveImage(long userId, String path) throws IOException {
		String mesg = "Saving image failed!!!!!!!!!!!!";
		// get hibernate session from SF
		Session session = getFactory().getCurrentSession();
		// begin Tx
		Transaction tx = session.beginTransaction();
		try {
//1. get persistent user details from it's id
			User user = session.get(User.class, userId);
			if (user != null) {// user : PERSISTENT
								// 2. From image path --> read bin file contents : byte[] --> simply invoke
								// setImage
				/*
				 * method of FileUtils class : Apache supplied (3rd party JAR) public static
				 * byte[] readFileToByteArray(File file) throws IOException
				 */
				// 3. Create java.io.File class instance n validate it
				File file = new File(path);
				if (file.isFile() && file.canRead()) {
					// valid readable data file
					user.setImage(FileUtils.readFileToByteArray(file));// modifying the state of the PERSISTENT entity
					mesg = "Saved image contents in DB";
				} else
					mesg = "Saving image failed : Invalid File Path";
			} else
				mesg = "Saving image failed : Invalid user id!!!!!!!!!";
			tx.commit();// hib perform auto dirtyh chking --> update
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return mesg;
	}

	@Override
	public String restoreImage(long userId, String path) throws IOException {
		String mesg = "Restoring image failed !!!!!!!!!!";
		// get hibernate session from SF
		Session session = getFactory().getCurrentSession();
		// begin Tx
		Transaction tx = session.beginTransaction();
		try {
//1 : get user details from db , using it's id
			User user = session.get(User.class, userId);
			if (user != null) {
				// user valid : PERSISTENT
				/*
				 * Method of FileUtils : public static void writeByteArrayToFile(File file,
				 * byte[] data) throws IOException
				 */
				if (user.getImage() != null) // img is assigned to this user
				{
					FileUtils.writeByteArrayToFile(new File(path), user.getImage());
					mesg = "Restored image for user " + user.getName();

				} else
					mesg = "Restoring image failed : no image assigned for this user!!!!!!!!!!!!";

			} else
				mesg = "Restoring image failed : invalid user id";

			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}
		return mesg;
	}

}

package tester;

import static utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.UserDaoImpl;
import pojos.Role;
import pojos.User;
import static java.time.LocalDate.parse;
import static pojos.Role.valueOf;

public class SaveImage {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory();Scanner sc=new Scanner(System.in)) {
			// create user dao instance
			UserDaoImpl userDao = new UserDaoImpl();// def ctor
			System.out.println("Enter user id ");
			long userId=sc.nextLong();
			sc.nextLine();//reading off pending new line char from the scanner
			System.out.println("Enter image path");
			System.out.println(userDao.saveImage(userId, sc.nextLine()));		
			
		}//sc.close() , sf.close()
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

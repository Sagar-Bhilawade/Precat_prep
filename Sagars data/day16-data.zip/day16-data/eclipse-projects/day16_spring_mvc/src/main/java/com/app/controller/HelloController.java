package com.app.controller;

import java.time.LocalDateTime;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller // MANDATORY : to tell SC following is a spring bean containing req handling
			// logic
//singleton n eager
public class HelloController {
	public HelloController() {
		System.out.println("in ctor of " + getClass());
	}
	@PostConstruct
	public void anyInit()
	{
		System.out.println("in init ");
	}
	//add a req handling method : to send hello resp to the clnt
	@RequestMapping("/hello")
	public String sayHello()
	{
		System.out.println("in say hello");
		return "/welcome";//logical view name(forward view name) : LVN
		//V.R : simply wraps LVN within prefix n suffix --> Actual view name(AVN)
		
		//  /WBB-INF/views/welcome.jsp
	}
	//add req handling method to test Model n View (sending results from Handler ---> View Layer : thro' D.S)
	@GetMapping("/hello2")
	public ModelAndView testModelAndView()
	{
		System.out.println("in test m n v");
		//add server time stamp in the MnV
		//o.s.w.s.ModelAndView(String logViewName,String modelAttrName,Object attVal)
		return new ModelAndView("/welcome", "server_ts", LocalDateTime.now());
		//Who is returning What to Whom?
		//Handler rets MnV object to D.S
		//D.S sends LVN ---> V.R --> AVN (/WEB-INF/views/welcome.jsp)
		//D.S chks for results (for model attrs) -->present --> stores under req scope
		//forward the clnt ---> view layer --> welcome.jsp
	}
	
}

package com.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user")
public class UserController {
	public UserController() {
		System.out.println("in ctor of "+getClass());
	}
	//add req handling method to show the login form
	@GetMapping("/login")
	public String showLoginForm()
	{
		System.out.println("in show login form"); 
		//will u have any results to send to D.S ? NO 
		return "/user/login";//AVN : /WEB-INF/views/user/login.jsp
	}
	//add a new method : processing login form
	@PostMapping("/login")
	public String processLoginForm()
	{
		System.out.println("in process login form ");
		return "/user/display";
	}
}

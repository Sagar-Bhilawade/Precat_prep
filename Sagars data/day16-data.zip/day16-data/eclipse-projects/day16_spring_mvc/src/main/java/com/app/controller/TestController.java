package com.app.controller;

import java.util.Arrays;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // mandatory
@RequestMapping("/test") // Optional BUT reco for functional separation . To tell SC : any request
							// (GET/PUT/POST....) starting with /test as a URL pattern will be intercepted
							// by TestController
public class TestController {
	public TestController() {
		System.out.println("in ctor of " + getClass());
	}

	// add request handling method to test Model Map
	@GetMapping("/test1")
	public String testModelMap(Model map) {
		// model map instance
		System.out.println("in test model map " + map);// {}
		// how to add attrs under Model Map?
		// o.s.ui.Model : public Model addAttribute(String nm,Obejct val)
		map.addAttribute("server_date", new Date()).addAttribute("num_list", Arrays.asList(10, 20, 30, 40));
		System.out.println("model map "+map);//populated model map
	//	return "/results/page1";// AVN resolved by the V.R : /WEB-INF/views/results/page1.jsp
		return "/test/test1";//AVN resolved by the V.R : /WEB-INF/views/test/test1.jsp
		//Handler(R.H.C) --> explicitly rets LVN ---> D.S
		//BUT SC IMPLICITLY rets model map --> D.S
		//D.S  --> LVN --> V.R ---> AVN
		//D.S chks --for model attrs --> yes --> adds it under request scope --> foward --view layer (JSP)
		
	}

}

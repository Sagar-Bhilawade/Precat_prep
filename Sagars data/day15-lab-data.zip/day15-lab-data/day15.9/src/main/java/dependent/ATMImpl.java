package dependent;

// cash : double : ctor based D.I
//transport : setter based D.I
import dependency.Transport;

public class ATMImpl implements ATM {
	private double cash;
	private Transport myTransport;// =new HttpTransport();
	// constr based D.I

	public ATMImpl(double myCash) {
		cash = myCash;
		System.out.println("in cnstr of " + getClass().getName() + " " + cash + " " + myTransport);// 10 l null
	}

	@Override
	public void deposit(double amt) {
		System.out.println("depositing " + amt);
		byte[] data = ("depositing " + amt).getBytes();
		myTransport.informBank(data);// B.L using dependency

	}

	@Override
	public void withdraw(double amt) {
		System.out.println("withdrawing " + amt);
		byte[] data = ("withdrawing " + amt).getBytes();
		myTransport.informBank(data);
	}

	// custom init method
	public void myInit() {
		System.out.println("in init " +cash+" "+myTransport);//cash not null
	}

	// custom destroy method
	public void myDestroy() {
		System.out.println("in destroy " + myTransport);// not null
	}
	// setter

	public void setMyTransport(Transport myTransport) {
		this.myTransport = myTransport;
		System.out.println("in setter " + this.myTransport);
	}

}

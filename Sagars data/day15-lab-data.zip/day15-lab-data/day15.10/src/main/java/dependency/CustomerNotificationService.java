package dependency;

public interface CustomerNotificationService {
	void notifyCustomer(String mesg);
}

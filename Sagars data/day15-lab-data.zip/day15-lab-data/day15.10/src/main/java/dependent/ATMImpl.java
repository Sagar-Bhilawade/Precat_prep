package dependent;

import dependency.CustomerNotificationService;
import dependency.Transport;

public class ATMImpl implements ATM {
	private Transport myTransport;
	private CustomerNotificationService[] service;

	public ATMImpl() {
		System.out.println("in cnstr of " + getClass().getName() + " " + myTransport);// not null
	}

	@Override
	public void deposit(double amt) {
		System.out.println("depositing " + amt);
		byte[] data = ("depositing " + amt).getBytes();
		myTransport.informBank(data);// B.L using dependency
		for (CustomerNotificationService s : service)
			s.notifyCustomer("You have deposited " + amt);

	}

	@Override
	public void withdraw(double amt) {
		System.out.println("withdrawing " + amt);
		byte[] data = ("withdrawing " + amt).getBytes();
		myTransport.informBank(data);
		for (CustomerNotificationService s : service)
			s.notifyCustomer("You have withdrawn " + amt);
	}

	// custom init method
	public void myInit() {
		System.out.println("in init " + myTransport);// not null
	}

	// custom destroy method
	public void myDestroy() {
		System.out.println("in destroy " + myTransport);// not null
	}

	// setter based D.I
	public void setMyTransport(Transport myTransport) {
		this.myTransport = myTransport;
		System.out.println("in set transport " + this.myTransport);

	}

	// setter based D.I
	public void setService(CustomerNotificationService[] service) {
		this.service = service;
		System.out.println("in set  notification service " + this.service);
	}

}

package com.app.dao;

import java.util.List;

import com.app.pojos.Topic;

public interface ITopicDao {
//add a method to list all the topics
	List<Topic> getAllTopics();
}

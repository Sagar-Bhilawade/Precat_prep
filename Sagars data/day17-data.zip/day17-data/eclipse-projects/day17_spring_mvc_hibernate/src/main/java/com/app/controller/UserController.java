package com.app.controller;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.RoleEnum;
import com.app.pojos.User;
import com.app.service.IUserService;

@Controller
@RequestMapping("/user")
public class UserController {
	// dependency : service layer i/f
	@Autowired // (required=true)
	private IUserService userService;

	public UserController() {
		System.out.println("in ctor of " + getClass() + " " + userService);// null
	}

	@PostConstruct
	public void init() {
		System.out.println("in init " + userService);// not null
	}

	// add req handling method to show the login form
	@GetMapping("/login")
	public String showLoginForm() {
		System.out.println("in show login form");
		// will u have any results to send to D.S ? NO
		return "/user/login";// AVN : /WEB-INF/views/user/login.jsp
	}

	// add a new method : processing login form
	@PostMapping("/login") // =@RequestMapping : method=POST
	// @RequestParam : method arg level annotation => binding between req param n
	// req handling method arg name
	// String em=request.getParamter("em"); String
	// password=request.getParamter("pass");
	//dependencies : 3 ( 2 rq params + 1 emtpy model map)
	public String processLoginForm(@RequestParam String em, 
			@RequestParam(name = "pass") String password,Model map) {
		System.out.println("in process login form " + em + " " + password);// actual em n password values
		// for authentication : DB based : simply call service layer method
		try {
			User user = userService.authenticateUser(em, password);
			//store validated user details under model map
			map.addAttribute("user_details", user);
			//=> valid login (authentication success) --> proceed to authorization
			if(user.getRole() == RoleEnum.ADMIN) //admin user : forward admin to admin.jsp
				return "/admin/display";//LVN --> D.S--> V.R ---> /WEB-INF/views/admin/display.jsp
			if(user.getRole() == RoleEnum.AUTHOR) //author user : forward author to display.jsp
				return "/author/display";//LVN --> D.S--> V.R ---> /WEB-INF/views/author/display.jsp		
				//=>customer logged in : topics page
			return "/customer/topics";
		} catch (RuntimeException e) {
			System.out.println("err in " + getClass() + " err " + e);
			//=> invalid login ---> forward the clnt to the login form
			map.addAttribute("mesg", "Invalid Login , Pls retry !!!!!!!!!!!!");
			return "/user/login";//Handler(RHC --> LVN --> D.S) : AVN : /WEB-INF/views/user/login.jsp
		}		
	}
}

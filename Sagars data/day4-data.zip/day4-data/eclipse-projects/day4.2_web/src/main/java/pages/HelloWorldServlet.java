package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@SuppressWarnings("serial")
@WebServlet("/hello")//Mandatory annotation to tell WC , following is the servlet mapped to incoming url-pattern
// : /hello
//Map : key : /hello
//value  : pages.HelloWorldServlet
public class HelloWorldServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("in do-get "+Thread.currentThread());//nm prio thrd grp
		//1. set resp content type : resp header
		resp.setContentType("text/html");
		//2 . To send dyn resp : get o/p stream (java.io) to send text resp from server ---> clnt
		//pw => char , buffered , o/p strm connected from server --> clnt , meant for sending char data
		try(PrintWriter pw=resp.getWriter())
		{
			pw.print("<h4> Welcome to servlet @ "+LocalDateTime.now()+"</h4>");
		}//pw.close =>resp body will be rendered / committed ---> sent to clnt browser
		
	}

	@Override
	public void destroy() {
		System.out.println("in destroy "+Thread.currentThread());//nm prio thrd grp
	}

	@Override
	public void init() throws ServletException {
		System.out.println("in init "+Thread.currentThread());//nm prio thrd grp
	}
	//init , destroy , service ---> doGet
	

}

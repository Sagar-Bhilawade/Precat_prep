package dao;

import java.sql.*;
import static utils.DBUtils.*;

public class BankAccountDaoImpl implements IBankAccountDao {
	//state
	private Connection connection;
	private CallableStatement cst1;
	
	//ctor
	public BankAccountDaoImpl() throws SQLException{
		// get cn from db utils
		connection=openConnection();
		//API of Connection i/f 
		//CST prepareCall(String sql) throws SQLException
		cst1=connection.prepareCall("{call transfer_funds(?,?,?,?,?)}");//invocation syntax for calling proc
		//can u set IN params ? NO
		//can u register OUT params here ? YES
		//API of CST
		//public void registerOutParameter(int paramPos,int sqlType) throws SQLException
		cst1.registerOutParameter(4,Types.DOUBLE);
		cst1.registerOutParameter(5,Types.DOUBLE);
		System.out.println("acct dao created....");
		
	}
	

	@Override
	public String transferFunds(int srcId, int destId, double transferAmount) throws SQLException {
		// set IN params
		cst1.setInt(1, srcId);
		cst1.setInt(2, destId);
		cst1.setDouble(3, transferAmount);
		//exec stored proc
		cst1.execute();		
		return "Updated src balance "+cst1.getDouble(4)+" dest balance "+cst1.getDouble(5);
	}
	
	public void cleanUp() throws SQLException
	{
		if(cst1 != null)
			cst1.close();
		closeConnection();
	}

}

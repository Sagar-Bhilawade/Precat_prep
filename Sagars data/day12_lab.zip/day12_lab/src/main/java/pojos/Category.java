package pojos;

public enum Category {
	BREAD, BISCUITS, OIL, FRUITS, COSMETCS, BOOKS
}

package pojos;
/*
 * productId , name,description,category,price,manufacture date, quantity
 */

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="products")
public class Product {
	@Id //PK constraint
	@GeneratedValue(strategy = GenerationType.IDENTITY) //extra : auto increment
	@Column(name="product_id")
	private Long productId;
	@Column(length = 30,unique = true)
	private String name;
	private String description;
	@Enumerated(EnumType.STRING)
	@Column(length = 30)
	private Category category;
	private double price;
	@Column(name="manufacture_date")
	private LocalDate manufactureDate;
	private int quantity;
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product(String name, String description, Category category, double price, LocalDate manufactureDate,
			int quantity) {
		super();
		this.name = name;
		this.description = description;
		this.category = category;
		this.price = price;
		this.manufactureDate = manufactureDate;
		this.quantity = quantity;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public LocalDate getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(LocalDate manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", description=" + description + ", category="
				+ category + ", price=" + price + ", manufactureDate=" + manufactureDate + ", quantity=" + quantity
				+ "]";
	}
	

}

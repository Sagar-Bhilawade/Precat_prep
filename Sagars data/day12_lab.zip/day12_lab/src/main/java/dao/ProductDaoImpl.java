package dao;

import static utils.HibernateUtils.getFactory;

import java.util.List;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Category;
import pojos.Product;

public class ProductDaoImpl implements IProductDao {

	@Override
	public List<String> getAllDistinctCategories() {
		List<String> categoryNames = null;
		// jpql
		String jpql = "select distinct p.category from Product p";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin tx
		Transaction tx = session.beginTransaction();
		try {
			// exec jpql
			categoryNames = session.createQuery(jpql, Category.class).// Query
					getResultStream() // Stream<Category>
					.map(c -> c.name()) // Stream<String>
					.collect(Collectors.toList());
			// commit tx
			tx.commit();

		} catch (RuntimeException e) {
			// rollback tx n throw exc
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return categoryNames;
	}

	@Override
	public String addProduct(Product p) {
		String mesg = "Adding new product failed!";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(p);
			// p : PERSISTENT
			tx.commit();
			mesg = "Add new product with ID " + p.getProductId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public List<Product> findByCategory(Category category) {
		List<Product> productList = null;
		String jpql = "select p from Product p where p.category=:cat";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin tx
		Transaction tx = session.beginTransaction();
		try {
			productList = session.createQuery(jpql, Product.class).
					setParameter("cat", category).getResultList();

			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return productList;
	}

}

package dao;

import java.util.List;

import pojos.Category;
import pojos.Product;

public interface IProductDao {
	/*
	 * 5.1 Add a method to fetch all distinct categories eg : List<String>
	 * getAllDistinctCategories()
	 * 
	 * 5.2 Add a method to insert new product details String addProduct(Product p);
	 * 
	 * 5.3 Add a method to search products by category List<Product>
	 * findByCategory(Category category);//Category : enum
	 */
	List<String> getAllDistinctCategories();
	String addProduct(Product p);
	 List<Product> findByCategory(Category category);
	

}

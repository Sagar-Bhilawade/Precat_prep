package beans;

import java.time.LocalDate;
import java.util.List;

import dao.ProductDaoImpl;
import pojos.Category;
import pojos.Product;

public class ProductBean {
	// dependency : dao
	private ProductDaoImpl productDao;
	// product details sent from the web client
	private String category;
	private String name;
	private String desc;
	private double price;
	private String manuDate;
	private int quantity;

	public ProductBean() {
		// create dao instance
		productDao = new ProductDaoImpl();
		System.out.println("product bean created...");
	}
	// setters n getters

	public ProductDaoImpl getProductDao() {
		return productDao;
	}

	public void setProductDao(ProductDaoImpl productDao) {
		this.productDao = productDao;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getManuDate() {
		return manuDate;
	}

	public void setManuDate(String manuDate) {
		this.manuDate = manuDate;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	//add B.L method to fetch all distinct categories from dao
	List<String> getCategories()
	{
		return productDao.getAllDistinctCategories();
	}

	// add B.L method to insert new product details
	public String addNewProduct() {
		// 1 . create transient product pojo
		/*
		 * String name, String description, Category category, double price, LocalDate
		 * manufactureDate, int quantity
		 */
		Product product = new Product(name, desc, Category.valueOf(category), price, LocalDate.parse(manuDate),
				quantity);

		//2.  invoke dao's method for persistence
		return productDao.addProduct(product);
	}

}

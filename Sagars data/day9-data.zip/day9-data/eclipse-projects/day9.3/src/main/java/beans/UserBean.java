package beans;

import java.sql.SQLException;

import dao.UserDaoImpl;
import pojos.Role;
import pojos.User;

public class UserBean {
//state (properties)
	// clnt state
	private String email;
	private String password;
	// dependency of Java bean (JB)
	private UserDaoImpl userDao;
	// validate user details
	private User userDetails;

	// def ctor
	public UserBean() throws SQLException {
		// conventional prog : dependent obj(JB) is managing it's own dependency(DAO
		// layer)
		userDao = new UserDaoImpl();
		System.out.println("user bean created....");
	}

	// setters n getters
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserDaoImpl getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDaoImpl userDao) {
		this.userDao = userDao;
	}

	public User getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(User userDetails) {
		this.userDetails = userDetails;
	}

	// Add B.L method for user authentication n role based authorization
	public String validateUser() throws SQLException {
		System.out.println("in validate user " + email + " " + password);// not null !!!!!!!!!!!!!
		// JB invokes DAO's for user authentication
		userDetails = userDao.authenticateUser(email, password);
		if (userDetails != null) {
			// authentication success (valid login) --> proceed to role based authorization
			if (userDetails.getUserRole() == Role.ADMIN) // => admin login success
				return "admin";
			// => customer login
			return "topics";
		}
		// => invalid login
		return "login";// returning dynamic navigational outcome !!!!!!!!!!!(JB informs the upper layer
						// : where to navigate the clnt next)
	}

}

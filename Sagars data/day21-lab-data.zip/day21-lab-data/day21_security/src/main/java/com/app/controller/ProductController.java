package com.app.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/products")
public class ProductController {
	/*
	 * /view : any one should be able view the products /purchase : customer should
	 * be able to purchase products /add : admin should be able to add the products
	 * /categories : only authenticated user (any role !) can browse the categories
	 */
	@GetMapping("/view")
	public String viewProducts() {
		return "any one can view the products ...w/o authentication";
	}

	@GetMapping("/add")
	public String addProducts() {
		return "only admin will be able to add  the products ...authentication+admin role ";
	}

	@GetMapping("/purchase")
	public String purchaseProducts() {
		return "only customer can purchase the products ...authentication+customer role";
	}

	@GetMapping("/categories")
	public String viewCategories() {
		return "any one can view the categories  ...with successful authentication";
	}

}

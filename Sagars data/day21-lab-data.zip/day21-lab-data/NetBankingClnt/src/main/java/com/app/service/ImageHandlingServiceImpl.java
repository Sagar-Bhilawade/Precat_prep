package com.app.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.annotation.PostConstruct;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.app.custom_exception.ResourceNotFoundException;
import com.app.dao.EmployeeRespository;
import com.app.dto.EmployeeDTO;
import com.app.entities.Employee;

import lombok.extern.slf4j.Slf4j;

@Service
@Transactional // required only for storing / retrieving the image path form emp table
@Slf4j
public class ImageHandlingServiceImpl implements ImageHandlingService {
	// dep : emp repo
	@Autowired
	private EmployeeRespository empRepo;
	// add model mapper
	@Autowired
	private ModelMapper mapper;
	// SpEL
	@Value("${file.upload.folder}")
	private String folder;

	@PostConstruct
	public void anyInit() {
		log.info("in init {} ", folder);
		// create "images" folder : if one does not exist!
		File dir = new File(folder);
		if (!dir.exists())
			log.info("dir created {} ", dir.mkdirs());
		else
			log.info("dir alrdy exists.... ");
	}

	@Override
	public EmployeeDTO uploadContents(long empId, MultipartFile imageFile) throws IOException {
		// validate emp id
		Employee emp = empRepo.findById(empId).orElseThrow(() -> new ResourceNotFoundException("Invalid Emp Id"));
		// emp id valid , emp : PERSISTENT
		// create the image path =folder + orig file name
		String imagePath = folder.concat(File.separator).concat(imageFile.getOriginalFilename());
		// copy the contents from multipart file --> destination path
		// java.nio.file.Files : public boolean copy(InputStream in , Path
		// dest,CopyOptions options)
		log.info("bytes copied {} ",
				Files.copy(imageFile.getInputStream(), Paths.get(imagePath), StandardCopyOption.REPLACE_EXISTING));
		// store image path in db
		emp.setImagePath(imagePath);// modifying the state of persistent entity
		return mapper.map(emp, EmployeeDTO.class);
	}
	// NOTE : in case of storing image in DB : entity property byte[] --> blob
	// cloumn type in db
	// Simply emp.setImage(imageFile.getBytes());

	@Override
	public byte[] restoreContents(long empId) throws IOException{
		// get emp details from emp id;
		Employee emp = empRepo.findById(empId).orElseThrow(() -> new ResourceNotFoundException("Invalid Emp Id"));
		// => emp id valid , emp : PERSISTENT
		//chekc if image path is set
		if(emp.getImagePath() == null)
			throw new ResourceNotFoundException("Image doesn't exist");
		//=> image exists
		//for reading bin contents : Files.readAllBytes(Path arg)
		return Files.readAllBytes(Paths.get(emp.getImagePath()));
	}
	// NOTE : in case of restoring image from DB : entity property byte[] --> blob
	//simply invoke emp.getImage() ---> byte[] --> controller

}

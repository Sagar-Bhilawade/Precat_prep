package com.app.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exception.ResourceNotFoundException;
import com.app.dao.EmployeeRespository;
import com.app.dto.EmployeeDTO;
import com.app.dto.LoginRequestDTO;
import com.app.entities.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {
	// dep : dao layer i/f
	@Autowired
	private EmployeeRespository empRepo;
	//dep : model mapper bean : used for mapping between : Entity n DTO
	@Autowired
	private ModelMapper mapper;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}

	@Override
	public Employee insertEmpDetails(Employee transientEmp) {
		// TODO Auto-generated method stub
		return empRepo.save(transientEmp);
	}// @Transaction method rets ---> tx boundary --> no run time exc --> tx.commit
		// --> hib performs auto dirty chking -->hib session.flush --> insert --> L1
		// cache destroyed , pooled out (Hikari) cn rets to db cp -> session closed!
		// rets Employee : DETACHED

	@Override
	public String deleteEmpDetails(long empId) {
		String mesg = "Deleting emp details failed !!!!!";
		// if you want to confirm the id :
		if (empRepo.existsById(empId)) {
			empRepo.deleteById(empId);
			mesg = "Deleted emp details of emp of " + empId;
		}
		return mesg;

	}

	@Override
	public Employee getEmpDetails(long empId) {
		// TODO Auto-generated method stub
		return empRepo.findById(empId).orElseThrow(() -> new ResourceNotFoundException("Invalid Emp ID!!!!!!"));
	}

	@Override
	public Employee updateEmpDetails(Employee detachedEmp) {
		empRepo.findById(detachedEmp.getId())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Emp ID!!!!!! : Can't Update details"));
		// => valid emp id
		return empRepo.save(detachedEmp);// update
	}

	@Override
	public EmployeeDTO authenticateEmployee(LoginRequestDTO request) {
		// invoke dao's method for auth.
		Employee empEntity = empRepo.findByEmailAndPassword(request.getEmail(), request.getPassword())
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Credentials!!!!"));
		//map : Emp ent --> Emp dto
		return mapper.map(empEntity, EmployeeDTO.class);
	}

}

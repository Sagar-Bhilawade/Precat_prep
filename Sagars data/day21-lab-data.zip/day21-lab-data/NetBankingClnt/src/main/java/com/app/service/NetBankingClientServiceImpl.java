package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.app.custom_exception.ResourceNotFoundException;
import com.app.dao.EmployeeRespository;
import com.app.dto.BankAcctDTO;
import com.app.entities.Employee;

@Service
@Transactional // only for emp id validation
public class NetBankingClientServiceImpl implements INetBankingClientService {
	// dep : emp repo : for getting emp details
	@Autowired
	private EmployeeRespository empRepo;
	// add a field
	private RestTemplate restTemplate;
	// dep : RestTemplateBuilder : constr based D.I
	//SpEL : spring expression language
	@Value("${REST.GET.URL}")
	private String getURL;

	@Autowired
	public NetBankingClientServiceImpl(RestTemplateBuilder builder) {
		// builder : auot injected by Spring boot frmwork
		System.out.println("building rest template");
		restTemplate = builder.build();
	}

	@Override
	public BankAcctDTO getEmpAcctDetails(long empId, int acctNo) {
		Employee emp = empRepo.findById(empId)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Employee ID!!!!"));
		// => emp id valid --> proceed to making a RST call to the net banking REST
		// server
		// o.s.web.client.RestTemplate : ResponseEntity<T> getForEntity(String url,
		// Class<T> respTypeClass,Object... pathVars) throws RestClntExc
		System.out.println("get url "+getURL);
		ResponseEntity<BankAcctDTO> respEntity = restTemplate.getForEntity
				(getURL, BankAcctDTO.class, acctNo);
		return respEntity.getBody();
	}

}

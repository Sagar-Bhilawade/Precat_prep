package com.app.controller;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.dto.ApiResponse;
import com.app.dto.LoginRequestDTO;
import com.app.entities.Employee;
import com.app.service.IEmployeeService;
import com.app.service.INetBankingClientService;
import com.app.service.ImageHandlingService;

import lombok.extern.slf4j.Slf4j;

@RestController // =@Controller + @ResponseBody
@RequestMapping("/api/employees") // resource : class level pattern
@CrossOrigin(origins = "http://localhost:3000")
@Validated // added for enabling validation support for req params n path vars
@Slf4j
public class EmployeeController {
	// Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	// dep : service layer i/f
	@Autowired
	private IEmployeeService empService;

	// dep : net banking clnt service
	@Autowired
	private INetBankingClientService netBankcingClientService;

	// dep : for image handling
	@Autowired
	private ImageHandlingService imageService;

	public EmployeeController() {
		// System.out.println("in ctor of " + getClass());
		log.info("in ctor {} ", getClass());
	}

	@PostConstruct
	public void init() {
		log.info("in init {} ", empService.getClass());// F.Q cls of service impl : com.app.service.EmployeeServiceImpl
	}

	// add req handling method(REST API endpoint) to ret list of all emps
	@GetMapping
	public List<Employee> fetchAllEmpDetails() {
		System.out.println("in fetch all ");
		return empService.getAllEmployees();

	}

	// add req handling method(REST API endpoint) to create a new resource : Emp
	@PostMapping
	public ResponseEntity<?> addNewEmp(@RequestBody @Valid Employee emp) {
		try {
			System.out.println("in add new emp " + emp.getId());// id : null

			return ResponseEntity.status(HttpStatus.CREATED).body(empService.insertEmpDetails(emp));
		} catch (RuntimeException e) {
			System.out.println("in add new emp err " + e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(e.getMessage()));
		}

	}

	// add req handling method(REST API endpoint) to delete emp details
	@DeleteMapping("/{eid}")
	public String deleteEmpDetails(@PathVariable @Valid @NotNull @Range(min = 1, max = 100) long eid) {
		System.out.println("in del emp dtls " + eid);
		return empService.deleteEmpDetails(eid);
	}

	// add req handling method(REST API endpoint) to get emp details by it's id
	@GetMapping("/{empId}")
	public ResponseEntity<?> getEmpDetails(
			@PathVariable @Valid @Range(min = 1, max = 100, message = "Emp id must be within 1-100") long empId) {
		// System.out.println("in get emp dtls");
		log.info("in get emp {}", empId);
//		try {
		// o.s.http.ResponseEntity(T body,HttpStatus stsCode)
		return new ResponseEntity<>(empService.getEmpDetails(empId), HttpStatus.OK);
//		} catch (RuntimeException e) {
//			System.out.println("err in emp controller " + e);
//			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);
//		}
	}

	// add req handling method(REST API endpoint) to update emp details
	@PutMapping
	public Employee updateEmpDetails(@RequestBody Employee emp) {
		System.out.println("in update  emp dtls" + emp);// not null id
		return empService.updateEmpDetails(emp);
	}

	// add req handling method(REST API endpoint) to authenticate(signin) emp
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateEmp(@RequestBody @Valid LoginRequestDTO request) {
		System.out.println("in auth emp " + request);
		return ResponseEntity.ok().body(empService.authenticateEmployee(request));
	}

	// add request handling method for fetching acct details of the emp
	// http://host:port/api/employees/{empId}/accounts/{acctNo}
	@GetMapping("/{empId}/accounts/{acctNo}")
	public ResponseEntity<?> getEmpAccountDetails(@PathVariable long empId, @PathVariable int acctNo) {
		System.out.println("in get emp a/c " + empId + " " + acctNo);
		return ResponseEntity.ok(netBankcingClientService.getEmpAcctDetails(empId, acctNo));
	}

	// add req handling method to upload an image n store it's path in db n contents
	// on the server side folder.
	// http://host:port/api/employees/{empId}/images
	@PostMapping("/{empId}/images")
	public ResponseEntity<?> uploadImage(@PathVariable long empId, @RequestParam MultipartFile imageFile)
			throws IOException {
		System.out.println("in upload image " + empId + " orig file name " + imageFile.getOriginalFilename() + " size "
				+ imageFile.getSize());
		return ResponseEntity.status(HttpStatus.CREATED).body(imageService.uploadContents(empId, imageFile));
	}
	//add req handling method to serve(download) the image from server side folder --> clnt
	@GetMapping(value = "/{empId}/images",produces = 
		{MediaType.IMAGE_GIF_VALUE,MediaType.IMAGE_JPEG_VALUE,MediaType.IMAGE_PNG_VALUE})
	public ResponseEntity<?> downloadImage(@PathVariable long empId) throws IOException
	{
		System.out.println("in downlaod img "+empId);
		return ResponseEntity.ok(imageService.restoreContents(empId));
	}

}

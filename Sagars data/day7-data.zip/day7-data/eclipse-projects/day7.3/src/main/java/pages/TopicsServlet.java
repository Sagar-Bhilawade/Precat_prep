package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.TopicDaoImpl;
import pojos.Topic;
import pojos.User;

/**
 * Servlet implementation class TopicsServlet
 */
@WebServlet("/topics")
public class TopicsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("in do-get of " + getClass());
		response.setContentType("text/html");
		try  {
			PrintWriter pw = response.getWriter();
			pw.print("<h5>In topics page....</h5>");
			//get validated user details from request scope
			User user=(User) request.getAttribute("user_dtls");
			if(user != null) {
				pw.print("<h5> User details from req scoped attr "+user+"</h5>");
				pw.print("<h5>Email "+request.getParameter("em")+"</h5>");//not null
			}
			else //=> un likely !!!!!!!
				pw.print("<h5> Request dispatching Failed !!!!!!!!!!!!</h5>");
				

		}
		catch (Exception e) {
			throw new ServletException("err in do-get of " + getClass(), e);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("in do-post of " + getClass());
		doGet(req, resp);
	}

}

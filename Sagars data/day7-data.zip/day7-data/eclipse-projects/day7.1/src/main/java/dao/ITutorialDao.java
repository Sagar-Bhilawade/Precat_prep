package dao;

import java.sql.SQLException;
import java.util.List;

import pojos.Tutorial;

public interface ITutorialDao {
//add a method to get all tut names for the selected topic id
	List<String> getTutorialNamesByTopicId(int topicId) throws SQLException;
	//add a method to fetch tut details selected by tut name
	Tutorial getTutorialDetailsByName(String tutName) throws SQLException;
	//add a method to update tut visits by tut name
	String updateTutorialVisitsByName(String tutName)  throws SQLException;
	
	
}

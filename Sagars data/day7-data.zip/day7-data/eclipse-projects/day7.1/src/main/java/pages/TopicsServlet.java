package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.TopicDaoImpl;
import pojos.Topic;
import pojos.User;

/**
 * Servlet implementation class TopicsServlet
 */
@WebServlet("/topics")
public class TopicsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			pw.print("<h5>In topics page....</h5>");
			// 1. get Session
			HttpSession hs = request.getSession();
			System.out.println("in topic page " + hs.isNew());// if cookies are enabled : false , disabled : true
			System.out.println("session id " + hs.getId());// if cookies are enabled : SAME , disabled : different
			// get clnt details from session
			// 2. HttpSession API : public Object getAttribute(String attrName)
			User userDetails = (User) hs.getAttribute("user_details");
			if (userDetails != null) {
				pw.print("<h5> User details from HttpSession " + userDetails + "</h5>");
				// get topic dao instance from HttpSession
				TopicDaoImpl topicDao = (TopicDaoImpl) hs.getAttribute("topic_dao");
				// get topic list from topic dao
				List<Topic> topics = topicDao.getAllTopics();
				// dyn form generation
				pw.print("<form action='tutorials'>");
				for (Topic t : topics)
					pw.print("<h5><input type='radio' name='topic_id' value='" + t.getTopicId() + "'/>"
							+ t.getTopicName() + "</h5>");
				pw.print("<h5><input type='submit' value='Choose A Topic'/></h5>");
				pw.print("</form>");

			} else
				pw.print("<h5> No Cookies !!!!!!!!!!!!! Session Management Failed !!!!!!!!!!!!!!!!!!!!!</h5>");

		} catch (Exception e) {
			throw new ServletException("err in do-get of " + getClass(), e);
		}
	}

}

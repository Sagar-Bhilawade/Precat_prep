package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.TutorialDaoImpl;
import pojos.Tutorial;

/**
 * Servlet implementation class TutorialDetails
 */
//http://localhost:8080/day7.1/tutorial_details?tut_name=Spring%20MVC
@WebServlet("/tutorial_details")
public class TutorialDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1 set cont type
		response.setContentType("text/html");
		//2. get PW
		try(PrintWriter pw=response.getWriter())
		{
			//3 . get existing session from WC
			HttpSession session=request.getSession();
			//get tut dao from session scope
			TutorialDaoImpl tutDao=(TutorialDaoImpl) session.getAttribute("tut_dao");
			if(tutDao != null)
			{
				//4.  get tut name from clnt (req param)
				String tutTitle=request.getParameter("tut_name");
				//Invoke dao's methods for update --> get
				System.out.println(tutDao.updateTutorialVisitsByName(tutTitle));
				Tutorial tutorial = tutDao.getTutorialDetailsByName(tutTitle);
				pw.print("<h5> Title :  "+tutTitle+"</h5>");
				pw.print("<h5> Author :  "+tutorial.getAuthor()+"</h5>");
				pw.print("<h5> Visits :  "+tutorial.getVisits()+"</h5>");
				pw.print("<h5> Contents :  "+tutorial.getContents()+"</h5>");
				//back link
				pw.print("<h5> <a href='tutorials?topic_id="+tutorial.getTopicId()+"'>Back</a></h5>");
				
			}
			else
				pw.print("<h5> NO Cookies !!!!!!! Session Tracking Failed !!!!!!!!!!!!!!!!</h5>");
			//logout link
			pw.print("<h5> <a href='logout'>Log Me Out</a></h5>");
	
				
		} catch (Exception e) {
			throw new ServletException("err in do-get of "+getClass(),e);
		}
	}

	

}

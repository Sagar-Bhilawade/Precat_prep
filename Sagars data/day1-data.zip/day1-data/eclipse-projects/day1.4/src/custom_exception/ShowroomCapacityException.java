package custom_exception;

public class ShowroomCapacityException extends Exception {
	public ShowroomCapacityException(String mesg) {
		super(mesg);
	}
}

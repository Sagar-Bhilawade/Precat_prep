package com.app.service;

import java.util.List;

import com.app.pojos.Tutorial;

public interface ITutorialService {
	List<String> getTutNamesByTopic(long topicId);

	Tutorial getTutDetails(String tutName);
}

package com.app.service;



import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exception.ResourceNotFoundException;
import com.app.dao.UserRepository;
import com.app.pojos.User;

@Service //Mandatory class level annotation to tell SC , follwoing is a spring bean : containing B.L
@Transactional //Mandatory class level annotation , to tell SC , to auto manage txs.
public class UserServiceImpl implements IUserService {
	//dependency : DAO layer i/f
	@Autowired
	private UserRepository userDao;

	@Override
	public User authenticateUser(String email, String pass) {
		// TODO Auto-generated method stub
		Optional<User> optional = userDao.findByEmailAndPassword(email, pass);
//		if(optional.isPresent())
//			return optional.get();
		//SAM of Supplier : public T get()
		return optional.orElseThrow(() -> new ResourceNotFoundException("Invalid email or password !!!!!!!!!!"));
	}

}

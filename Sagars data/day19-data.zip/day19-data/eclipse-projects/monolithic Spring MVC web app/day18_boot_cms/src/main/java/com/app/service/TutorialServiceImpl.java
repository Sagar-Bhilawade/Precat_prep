package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exception.ResourceNotFoundException;
import com.app.dao.TutorialRepository;
import com.app.pojos.Tutorial;

@Service
@Transactional
public class TutorialServiceImpl implements ITutorialService {
	// dep : tut repo
	@Autowired
	private TutorialRepository tutRepo;

	@Override
	public List<String> getTutNamesByTopic(long topicId) {
		// TODO Auto-generated method stub
		return tutRepo.findTutNamesByTopicId(topicId);
	}

	@Override
	public Tutorial getTutDetails(String tutName) {
		Tutorial tutorial = tutRepo.findByTutName(tutName)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid tut name!!!!!!!"));
		// tutorial : PERSISTENT
		// simply modify state of the persistent tut --> hibernate will perform auto
		// dirty chking upon commit : rets from service layer method
		tutorial.setVisits(tutorial.getVisits()+1);
		return tutorial;
	}// service layer rets detached Tutorial to the controller

}

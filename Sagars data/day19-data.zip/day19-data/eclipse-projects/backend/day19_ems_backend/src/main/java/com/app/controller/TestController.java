package com.app.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Product;

@RestController // MANDATRY cls level annotation,@RestController =@Controller at the cls level +
				// @ResponseBody addedd implicitly on ret type of req handling methods :
				// @ReqMapping/@GetMapping...
public class TestController {
	// add REST API end point(req handling method) to ret list of products
	@GetMapping("/products")
	public  List<Product> getAllProducts() {
		System.out.println("in get all products");
		return List.of(new Product(1, "Book 1",100),new Product(2, "Book 2",200),
				new Product(3, "Book 3",300),new Product(4, "Book 4",400));
	}
}

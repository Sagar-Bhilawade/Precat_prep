package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.entities.Employee;
import com.app.service.IEmployeeService;

@Controller
@RequestMapping("/dept/emp")
public class EmployeeController {
	//dep : emp service
	@Autowired
	private IEmployeeService empService;
	
	public EmployeeController() {
		System.out.println("in ctor of "+getClass());
		
	}
	//add a method to display list of emsp for particular dept
	@GetMapping("/list")
	public String listEmps(Model map,@RequestParam long deptId,HttpSession session)
	{
		System.out.println("in list emps "+deptId);
		map.addAttribute("emp_list",empService.findByDepartment(deptId));
		session.setAttribute("dept_id", deptId);
		return "/emp/list";//AVN : WEB-INF/views/emp/list.jsp		
	}
	//add a method to show the Model (Emp) --> form : Model --> View 
	@GetMapping("/add")
	public String showNewEmpForm(Employee emp) //SC map.addAttribute("employee",new Employee());
	{
		System.out.println("in show new emp form "+emp);
		return "/emp/show_form";
	}
	//add a method to process the form date(view) ---> bound to the Model (Employee)
	@PostMapping("/add")
	public String processNewEmpForm(HttpSession session,Employee e)
	{
		System.out.println("in process new emp form "+e);//all the fields set as per form data : except : emp id , dept id
		System.out.println("Added new emp "+empService.addEmpDetails(e,(long)session.getAttribute("dept_id")));
		return "redirect:/dept/emp/list";
	}
	

}

package pojos;

public enum Role {
	CUSTOMER, MANAGER, ADMIN
}

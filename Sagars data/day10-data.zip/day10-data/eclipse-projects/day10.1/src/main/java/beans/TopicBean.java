package beans;

import java.sql.SQLException;
import java.util.List;

import dao.TopicDaoImpl;
import pojos.Topic;

public class TopicBean {
//state : properties of JB
	//dependency : topic dao
	private TopicDaoImpl topicDao;
	//def ctor
	public TopicBean() throws SQLException{
		// create dao instance
		topicDao=new TopicDaoImpl();
		System.out.println("topic bean created...");
	}
	//getters
	public TopicDaoImpl getTopicDao() {
		return topicDao;
	}
	//Add B.L method to get list of all topics
	public List<Topic> getAllTopics() throws SQLException //method name can be anything !
	{
		return topicDao.getAllTopics();
	}
	
}

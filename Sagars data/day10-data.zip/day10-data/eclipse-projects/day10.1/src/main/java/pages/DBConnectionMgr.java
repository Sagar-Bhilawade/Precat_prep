package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import static utils.DBUtils.*;

import dao.TopicDaoImpl;
import dao.TutorialDaoImpl;
import dao.UserDaoImpl;
import pojos.Role;
import pojos.User;

/**
 * Servlet implementation class LoginServlet
 */

public class DBConnectionMgr extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	
	/**
	 * @see Servlet#init()
	 */
	@Override
	public void init() throws ServletException {
		ServletConfig config = getServletConfig();
		System.out.println("in init of " + getClass() + " servlet config " + config);// not null
		System.out.println("ctx "+getServletContext());//not null 
		// create user dao instance
		try {
			// open db connection
			openConnection(config.getInitParameter("url"), config.getInitParameter("user_name"),
					config.getInitParameter("password"));
		} catch (Exception e) {
			// ServletException(String mesg,Throwable rootCause)
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
		
			closeConnection();
		} catch (Exception e) {
			// report the err to WC : RuntimeExc : OPTIONAL BUT rec.
			throw new RuntimeException("err in destroy of " + getClass(), e);
		}
	}

}

package beans;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;

import dao.TutorialDaoImpl;
import pojos.Tutorial;

/*
 * http://localhost:8080/day10.1/process_form.jsp?topicId=3&title=Learning+JPA&author=Raj
 * &visits=10&pubDate=2022-04-25&contents=some+contents
 */
public class TutorialBean {
//state : properties
	//clnt 's state
	private int topicId;
	private String title;
	private String author;
	private int visits;
	private String pubDate;
	private String contents;
	//dependency : tut dao
	private TutorialDaoImpl tutDao;
	//message
	private String message;
	//def ctor
	public TutorialBean() throws SQLException {
		//create tut dao instance
		tutDao=new TutorialDaoImpl();
		System.out.println("tut bean created....");
	}
	//setters n getters
	public int getTopicId() {
		return topicId;
	}
	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getVisits() {
		return visits;
	}
	public void setVisits(int visits) {
		this.visits = visits;
	}
	public String getPubDate() {
		return pubDate;
	}
	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public TutorialDaoImpl getTutDao() {
		return tutDao;
	}
	public void setTutDao(TutorialDaoImpl tutDao) {
		this.tutDao = tutDao;
	}
	
	public String getMessage() {
		return message;
	}
	//add B.L method to validate tut details --if valid --insert tut details via DAO layer
	public String validateAndAddTutorial() throws SQLException
	{
		System.out.println("in validate "+topicId);
		//validation rules --string : length , 
		//parsing string ---> LocalDate
		LocalDate publishDate=LocalDate.parse(pubDate);
		//period btween pub date n current date
		long monthsElapsed=Period.between(publishDate, LocalDate.now()).toTotalMonths();
		if(contents.length() < 255 && monthsElapsed < 6) //=> valid tut
		{
			//create tut pojo
			//tutName, String author, Date publishDate, int visits, String contents, int topicId
			Tutorial tutorial=new Tutorial(title, author,Date.valueOf(publishDate), visits, contents, topicId);
			//invoke dao's method to insert tut contents in db
			message=tutDao.addNewTutorial(tutorial);
			return "admin";
		}
		//=>invalid contents 
		message="Invalid tutorial details , Please retry!!!!!!!!!";
		return "add_tut_form";
		
	}
	
	

}

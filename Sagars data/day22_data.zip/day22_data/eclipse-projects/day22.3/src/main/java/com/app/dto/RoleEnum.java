package com.app.dto;

public enum RoleEnum {
	ROLE_USER, ROLE_ADMIN,ROLE_CUSTOMER	
}

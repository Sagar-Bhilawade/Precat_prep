package com.app.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@EnableWebSecurity //to enable spring sec support
@Configuration //to be able to add @Bean : for configuring spring beans 
public class SecurityConfig {
	//dep : 
	@Autowired
	private PasswordEncoder encoder;
//add a method to configure a InMemUserDtlsMgr as a spring bean (authentication)
	@Bean
	public InMemoryUserDetailsManager configureInMem()
	{
		//create UserDetails <---User first n then pass them to the mgr
		UserDetails user1=User.withUsername("Rama").password(encoder.encode("12345")).roles("ADMIN").build();
		UserDetails user2=User.withUsername("Pranav").password(encoder.encode("2345")).roles("CUSTOMER").build();	
		UserDetails user3=User.withUsername("Riya").password(encoder.encode("2456")).roles("USER").build();	
		InMemoryUserDetailsManager mgr=new InMemoryUserDetailsManager(user1,user2,user3);
		return mgr;
	}
	//add a method to configure a spring bean for authorization
	@Bean
	public SecurityFilterChain configureAuth(HttpSecurity http) throws Exception
	{
		http.authorizeRequests(). //authorizing all requests
		antMatchers("/products/view").permitAll(). //any one w/o auth can view the products
		antMatchers("/products/add").hasRole("ADMIN").//only admin should be able to add products
		antMatchers("/products/purchase").hasRole("CUSTOMER").//only customer  should be able to purchase products
		anyRequest().authenticated() //viewing the categorirs : can be done by any auth user
		.and()
	//	.formLogin() //required only for spring MVC web app
		.httpBasic();		
		return http.build();
	}
}

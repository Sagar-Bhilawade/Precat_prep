package com.app.service;

public interface IService2 {
	void insertSecondAuthor();
}
package pojos;

public enum UserRole {
	CUSTOMER, ADMIN
}

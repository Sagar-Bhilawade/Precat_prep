package tester;

import java.sql.*;
import static utils.DBUtils.openConnection;

public class TestStatement {

	public static void main(String[] args) {
		try (// open fixed db conn
				Connection cn = openConnection();
				// create empty statement
				Statement st = cn.createStatement();
				// exec select query : ResultSet executeQuery(String sql) throws SQLExc
				ResultSet rst = st.executeQuery("select * from users order by reg_amt desc");) {
			//Iterate thro the RST
			while(rst.next())
			{
				//read row data
				System.out.printf("ID %d Name %s Email %s Reg Amount %.1f Reg Date %s %n",
						rst.getInt(1),rst.getString(2),rst.getString(3),rst.getDouble(5),rst.getDate(6));
			}

		} // JVM :rst.close , st.close , cn.close() => releasing DB resources
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

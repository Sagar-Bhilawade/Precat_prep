package tester;
import java.sql.*;
import static utils.DBUtils.openConnection;

public class TestDBConnection {

	public static void main(String[] args) {
		try(Connection cn=openConnection())
		{
			System.out.println("Connected to DB "+cn);
		} //JVM : cn.close() => releasing DB resources
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package tester;

import java.sql.*;
import java.util.Scanner;

import static utils.DBUtils.openConnection;

public class TestPreparedStatement {

	public static void main(String[] args) {
		String sql = "select id,name,reg_amt,reg_date from users where role=? and reg_date between ? and ?";
		try (Connection cn = openConnection();
				Scanner sc = new Scanner(System.in);
				// create PST from Cn to hold parameterized sql => pre parsed n pre compiled
				// statement
				PreparedStatement pst = cn.prepareStatement(sql);) {
			System.out.println("Enter role , begin date n end date (yr-mon-day)");
			// set IN params
			pst.setString(1, sc.next());// role
			pst.setDate(2, Date.valueOf(sc.next()));// begin date
			pst.setDate(3, Date.valueOf(sc.next()));// end date
			try (ResultSet rst = pst.executeQuery()) {
				while (rst.next())
					System.out.printf("ID %d Name %s Reg Amount %.1f Reg date %s %n", rst.getInt(1), rst.getString(2),
							rst.getDouble(3), rst.getDate(4));
			}

		} // JVM : cn.close() => releasing DB resources
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Tutorial;
import com.app.service.ITopicService;
import com.app.service.ITutorialService;
import com.app.service.IUserService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	// dep : topic service i/f
	@Autowired
	private ITopicService topicService;

	@Autowired
	private ITutorialService tutService;
	
	@Autowired
	private IUserService userService;

	public AdminController() {
		System.out.println("in ctor of " + getClass());
	}

//add request handling method to forward admin to status page
	@GetMapping("/status")
	public String showAdminStatus() {
		System.out.println("in admin status ");		
		return "/admin/status";
	}

	// add req handling method to show the form for adding new tut , under chosen
	// topic by specific author
	@GetMapping("/add_new_tut")
	public String addNewTutorialShowForm(Tutorial tut,Model map)
	//map.addAttribute("tutorial",new Tutorial());
	{
		
		System.out.println("in add new tut show form " +map);//populated map : size : 1 : "tutorial",new Tutorial()
		map.addAttribute("topic_list", topicService.getAllTopics());//findAll : spring Data JPA
		map.addAttribute("author_list",userService.getAllAuthors()); //custom query
		//map's size ???????? : 3
		return "/admin/add_tutorial";// AVN /WEB-INF/views/admin/add_tutorial.jsp
	}

	// upon form submission :add req handling method : to process form
	@PostMapping("/add_new_tut")
	public String addNewTutorialProcessForm(Tutorial transientTut, Model map,
			RedirectAttributes flashMap) {
		System.out.println("in add tut process form tut : " + transientTut);// except id --everything bound
																			// to user supplied values(View --> Model)
		System.out.println("tut's topic " + transientTut.getSelectedTopic());//only topic id will be 
		System.out.println("tut's author " + transientTut.getAuthor());//only user id(author id)
		try {
			flashMap.addFlashAttribute("mesg",
					tutService.validateNAddTutotrial(transientTut));
		} catch (RuntimeException e) {
			// in case of any errs --forward clnt to the view layer(add tut .jsp) ,
			// hightlighted with errs!
			map.addAttribute("err_mesg", e.getMessage());
			return "/admin/add_tutorial";// AVN /WEB-INF/views/admin/add_tutorial.jsp
		}
		// in case of success --redirect the clnt to admin status page with a status
		// mesg !
		return "redirect:/admin/status";

	}
}

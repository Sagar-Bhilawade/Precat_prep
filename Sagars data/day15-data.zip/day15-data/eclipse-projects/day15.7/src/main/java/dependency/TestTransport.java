package dependency;

import org.springframework.stereotype.Component;

@Component("test") // Mandatory cls level anno to tell SC , follwoing is a spring bean , whose life
			// cycle should be managed by SC
//singleton n eager
public class TestTransport implements Transport {
	public TestTransport() {
		System.out.println("in cnstr of " + getClass().getName());
	}

	@Override
	public void informBank(byte[] data) {
		System.out.println("informing bank using " + getClass().getName() + " layer");

	}

}

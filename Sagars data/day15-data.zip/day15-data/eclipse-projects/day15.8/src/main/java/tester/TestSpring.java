package tester;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import config.AppConfiguration;
import dependent.ATMImpl;

public class TestSpring {

	public static void main(String[] args) {
		try (AnnotationConfigApplicationContext ctx = 
				new AnnotationConfigApplicationContext(AppConfiguration.class)) {
			System.out.println("SC up n running .....");
			// get ready made bean ref from SC
			ATMImpl atm1 = ctx.getBean("my_atm", ATMImpl.class);
			// B.L
			atm1.deposit(12445);// soap transport layer
			ATMImpl atm2 = ctx.getBean("my_atm", ATMImpl.class);
			System.out.println(atm1 == atm2);// true : singleton

		} // ctx.close() => shut down SC
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}

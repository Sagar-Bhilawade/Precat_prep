package config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration // Mandatory cls level annotation to tell SC , following is a java config class
				// equivalent to bean-config.xml : <context:annotation-config/>
@ComponentScan(basePackages = {"dependent","dependency"})

public class AppConfiguration {
//will be adding LATER , methods @Bean => <bean id ..../>
}

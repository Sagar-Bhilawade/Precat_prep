package com.app.pojos;

public enum RoleEnum {
	ADMIN, AUTHOR, CUSTOMER
}

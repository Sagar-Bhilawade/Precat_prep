package com.app.entities;

public enum DeptNames {
	RND, MARKETING, FINANCE, PRODUCTION
}

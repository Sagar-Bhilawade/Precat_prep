package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="employees")
@Getter
@Setter
@ToString(exclude = "dept")
public class Employee extends BaseEntity{
	@Column(length = 30)
	@NotBlank(message = "Name is required")
	private String name;
	@Column(length = 100)
	@Length(min=20,max=90)
	private String address="Pune";
	@NotNull
	private double salary;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@NotNull
	private LocalDate joinDate;
	//uni dir asso between Dept 1<-----* Emp
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="department_id",nullable = false)
	private Department dept;

}

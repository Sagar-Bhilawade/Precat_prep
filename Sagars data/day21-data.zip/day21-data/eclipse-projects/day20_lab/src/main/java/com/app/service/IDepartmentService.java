package com.app.service;

import java.util.List;

import com.app.entities.Department;

public interface IDepartmentService {
//add a method to get list of all depts
	List<Department> getAllDepartments();
}

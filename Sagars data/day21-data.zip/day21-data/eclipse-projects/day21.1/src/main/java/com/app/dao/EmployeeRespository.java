package com.app.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.app.entities.Employee;

public interface EmployeeRespository extends JpaRepository<Employee, Long> {
//finder method : to get all emps by dept , ordered by desc salary
	List<Employee> findByDepartmentNameOrderBySalaryDesc(String deptName);

	// add a finder method to get emps joined within a date range
	List<Employee> findByJoinDateBetween(LocalDate start, LocalDate end);
	/*
	 * 3. Update sal by department i/p dept , sal incr
	 */
	@Modifying //MANDATORY for DML
	@Query("update Employee e set e.salary=e.salary+?1 where e.departmentName=?2")
	int updateEmpSalary(double salIncrement,String dept);
	//add a finder method for login
	Optional<Employee> findByEmailAndPassword(String em,String pass);
}

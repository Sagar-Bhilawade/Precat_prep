package com.app.service;

import com.app.dto.BankAcctDTO;

public interface INetBankingClientService {

	BankAcctDTO getEmpAcctDetails(long empId, int acctNo);

}

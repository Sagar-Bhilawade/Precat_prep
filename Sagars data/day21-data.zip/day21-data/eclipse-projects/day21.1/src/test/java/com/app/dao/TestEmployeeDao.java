package com.app.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.app.entities.Employee;

//@SpringBootTest //dis adv : SC in the test mode , will scan ALL components(rest controllers,service,dao)
@DataJpaTest // SC in the test mode , will scan ONLY DAO layer (Repository) beans
@AutoConfigureTestDatabase(replace = Replace.NONE) // => To tell SC in test mode , DO NOT replace actual DataSource by
													// the mem based.
class TestEmployeeDao {
	@Autowired
	private EmployeeRespository empRepo;

	@Test
	void testFindByDepartmentNameOrderBySalaryDesc() {
		assertNotNull(empRepo);
		List<Employee> list = empRepo.findByDepartmentNameOrderBySalaryDesc("RnD");
		//display only for our immediate confirmation
		list.forEach(System.out::println);		
		assertEquals(2, list.size());
	}
	
	@Test
	void testFindByJoinDateBetween()
	{
		List<Employee> list = empRepo.findByJoinDateBetween(LocalDate.of(2022, 4, 1),LocalDate.of(2023,3,31));
		list.forEach(System.out::println);		
		assertEquals(1, list.size());
	}
	
	@Test
//	@Rollback(false) : NOT Reco BUT can be used in special test scenarios
	void testUpdateEmpSalary()
	{
		int updateCount = empRepo.updateEmpSalary(5000,"Rnd");
		assertEquals(2,updateCount);
	}

}

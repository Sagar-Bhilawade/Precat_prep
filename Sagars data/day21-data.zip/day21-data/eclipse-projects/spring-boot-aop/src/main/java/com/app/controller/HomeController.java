package com.app.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;

@RestController
@RequestMapping("/")
public class HomeController {
	public HomeController() {
		System.out.println("in home controller");
	}

	@GetMapping
	public ResponseEntity<?> helloResponse() {
		return ResponseEntity.ok(new ApiResponse("Hello from REST "));
	}
}

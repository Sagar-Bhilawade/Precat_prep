package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.entities.Employee;
import com.app.service.IEmployeeService;

@RestController // =@Controller + @ResponseBody
@RequestMapping("/api/employees") // resource : class level pattern
@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeController {
	// dep : service layer i/f
	@Autowired
	private IEmployeeService empService;

	public EmployeeController() {
		System.out.println("in ctor of " + getClass());
	}

	// add req handling method(REST API endpoint) to ret list of all emps
	@GetMapping
	public List<Employee> fetchAllEmpDetails() {
		//System.out.println("in fetch all ");
		System.out.println("service impl "+empService.getClass());
		return empService.getAllEmployees();

	}

	// add req handling method(REST API endpoint) to create a new resource : Emp
	@PostMapping
	public Employee addNewEmp(@RequestBody Employee emp) {
		System.out.println("in add new emp " + emp);// id : null
		return empService.insertEmpDetails(emp);
	}

	// add req handling method(REST API endpoint) to delete emp details
	@DeleteMapping("/{eid}")
	public String deleteEmpDetails(@PathVariable long eid) {
		System.out.println("in del emp dtls " + eid);
		return empService.deleteEmpDetails(eid);
	}

	// add req handling method(REST API endpoint) to get emp details by it's id
	@GetMapping("/{empId}")
	public ResponseEntity<?> getEmpDetails(@PathVariable long empId) {
		System.out.println("in get emp dtls");
		try {
			//o.s.http.ResponseEntity(T body,HttpStatus stsCode)
			return   new ResponseEntity<>(empService.getEmpDetails(empId),HttpStatus.OK);
		} catch (RuntimeException e) {
			System.out.println("err in emp controller " + e);
			return new ResponseEntity<>(new ApiResponse(e.getMessage()),HttpStatus.NOT_FOUND);
		}
	}

	// add req handling method(REST API endpoint) to update emp details
	@PutMapping
	public Employee updateEmpDetails(@RequestBody Employee emp) {
		System.out.println("in update  emp dtls" + emp);// not null id
		return empService.updateEmpDetails(emp);
	}

}

package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
//JPA annotations
@Entity
@Table(name="emps_tbl")
public class Employee extends BaseEntity {
	@Column(length = 30,unique = true)
	private String name;
	@Column(length = 30)
	private String location;
	@Column(length = 40)
	@JsonProperty(value = "department")
	private String departmentName;//col : department_name
}

package dao;

import static utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Address;
import pojos.User;

public class AddressDaoImpl implements IAddressDao {

	@Override
	public String assignUserAddress(String email, Address address) {
		String jpql = "select u from User u where u.email=:em";
		String mesg = "Assigning address failed !!!!!!!!!!!!!";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// 1 . get user details using it's email
			User user = session.createQuery(jpql, User.class).setParameter("em", email).getSingleResult();
			// => email valid , user : PERSISTENT
			//2. establish uni dir relationship : Address ---> User
			address.setOwner(user);
			//3. persist the address
			session.persist(address);			
			tx.commit();
			mesg="Address assigned successfully for User with first Name "+user.getFirstName();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}

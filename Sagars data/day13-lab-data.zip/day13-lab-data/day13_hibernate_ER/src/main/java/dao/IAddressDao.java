package dao;

import pojos.Address;

public interface IAddressDao {
//add a method to assign the address for the existing user
	String assignUserAddress(String email,Address address);
}

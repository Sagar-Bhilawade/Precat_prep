package dao;

import pojos.User;
import static utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User user) {
		String mesg="User reg failed !!!!!!!!!!!";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(user);
			tx.commit();
			mesg="New User reged with ID "+user.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}

package pojos;

public enum Role {
	CUSTOMER, AUTHOR, ADMIN
}

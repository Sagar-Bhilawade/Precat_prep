package dao;

import static utils.HibernateUtils.getFactory;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Topic;
import pojos.Tutorial;
import pojos.User;

public class TutorialDaoImpl implements ITutorialDao {

	@Override
	public String addNewTutorialByAuthorAndTopic(Tutorial newTut, long authorId, long topicId) {
		String mesg = "Adding tutorial failed : Invalid topic or author id !!!!!!!!!!";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// 1. get author ref from it's id
			User author = session.get(User.class, authorId);
			// 2. get topic ref from it's id
			Topic topic = session.get(Topic.class, topicId);
			if (author != null && topic != null) {
				// 3. establish uni dir asso between entities : setters
				newTut.setAuthor(author);// tut--->Author
				newTut.setSelectedTopic(topic);// tut --> Topic
				session.persist(newTut);
				mesg = "Added a new tut for Author Name : " + author.getLastName() + " under topic "
						+ topic.getTopicName();
			}
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public List<Tutorial> getAllTutorials() {
		List<Tutorial> list=null;
		String  jpql="select t from Tutorial t";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			list=session.createQuery(jpql, Tutorial.class).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return list;
	}
	@Override
	public List<Tutorial> getAllTutorialsAndTopicDetails() {
		List<Tutorial> list=null;
		String  jpql="select t from Tutorial t  join fetch t.selectedTopic";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			list=session.createQuery(jpql, Tutorial.class).getResultList();
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return list;
	}

}

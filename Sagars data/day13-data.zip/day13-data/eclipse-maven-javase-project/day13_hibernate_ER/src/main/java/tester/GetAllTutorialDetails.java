package tester;

import static utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.TopicDaoImpl;
import dao.TutorialDaoImpl;
import dao.UserDaoImpl;
import pojos.Role;
import pojos.Topic;
import pojos.Tutorial;
import pojos.User;
import static java.time.LocalDate.parse;
import static pojos.Role.*;

public class GetAllTutorialDetails {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory()) {
			TutorialDaoImpl tutDao = new TutorialDaoImpl();
			tutDao.getAllTutorials().forEach(System.out::println);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

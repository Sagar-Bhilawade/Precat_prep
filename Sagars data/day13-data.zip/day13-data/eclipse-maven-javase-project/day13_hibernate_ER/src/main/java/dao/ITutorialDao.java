package dao;

import java.util.List;

import pojos.Tutorial;

public interface ITutorialDao {
	/*
	 * Add tut by author under existing topic
	 */
	/*
	 * In Full stack demo { "name" : ... "contents" : ... "author_id" : "topic_id"
	 * :... }
	 */
	String addNewTutorialByAuthorAndTopic(Tutorial newTut, long authorId, long topicId);

	// add a method to Get all tut details
	List<Tutorial> getAllTutorials();

	// add a method to Get tut n topic details
	List<Tutorial> getAllTutorialsAndTopicDetails();//tut n topic
}

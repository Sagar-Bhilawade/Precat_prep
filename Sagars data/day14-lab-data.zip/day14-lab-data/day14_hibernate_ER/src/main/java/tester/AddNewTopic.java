package tester;

import static utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.TopicDaoImpl;
import dao.UserDaoImpl;
import pojos.RoleEnum;
import pojos.Topic;
import pojos.User;
import static java.time.LocalDate.parse;
import static pojos.RoleEnum.*;

public class AddNewTopic {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			TopicDaoImpl topicDao = new TopicDaoImpl();
			System.out.println("Enter new topic details : name ");
			String name = sc.nextLine();
			System.out.println("Enter new topic desc ");
			System.out.println(topicDao.addNewTopic(new Topic(name, sc.nextLine())));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

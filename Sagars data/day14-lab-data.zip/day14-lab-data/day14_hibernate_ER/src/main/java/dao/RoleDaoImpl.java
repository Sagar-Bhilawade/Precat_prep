package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import static utils.HibernateUtils.getFactory;

import java.util.Set;
import java.util.stream.Collectors;

import pojos.RoleEntity;
import pojos.RoleEnum;

public class RoleDaoImpl implements IRoleDao {

	@Override
	public String addRole(RoleEntity role) {
		String mesg = "Adding new role failed!!!!!!";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(role);
			tx.commit();
			mesg = "Added new role";
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public Set<RoleEntity> getRolesByRoleName(Set<RoleEnum> roles) {
		Set<RoleEntity> roleEntities = null;
		String jpql = "select r from RoleEntity r where r.roleName in (:rls)";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin tx
		Transaction tx = session.beginTransaction();
		try {
			roleEntities=session.createQuery(jpql, RoleEntity.class)
					.setParameter("rls", roles).
					getResultStream()
					.collect(Collectors.toSet());
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return roleEntities;
	}

}

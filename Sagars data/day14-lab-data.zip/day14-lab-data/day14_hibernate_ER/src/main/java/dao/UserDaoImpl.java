package dao;

import pojos.RoleEntity;
import pojos.User;
import static utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class UserDaoImpl implements IUserDao {

	@Override
	public String registerUser(User user) {
		String mesg = "User reg failed !!!!!!!!!!!";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(user);
			tx.commit();
			mesg = "New User reged with ID " + user.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public String assignNewRole(long userId, long roleId) {
		String mesg="linking role to user failed";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin tx
		Transaction tx = session.beginTransaction();
		try {
			//1 . get user from it's is
			User user=session.get(User.class, userId);
			//2. get role from it's id
			RoleEntity role=session.get(RoleEntity.class, roleId);
			//3 null chk
			if(user != null && role != null)
			{
				//use helper method to esatblish a link between user n a role
				user.addRole(role);
				mesg="linking role successful";
			}
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}

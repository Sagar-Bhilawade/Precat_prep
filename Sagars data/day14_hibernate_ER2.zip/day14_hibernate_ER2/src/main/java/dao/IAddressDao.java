package dao;

import pojos.Address;

public interface IAddressDao {
//add a method to assign the address for the existing user
	String assignUserAddress(String email, Address address);

	// add a method to update the address for the existing user
	String updateUserAddress(long userId, Address updatedAddress);
}

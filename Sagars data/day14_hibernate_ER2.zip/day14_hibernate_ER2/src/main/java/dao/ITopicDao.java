package dao;

import pojos.Topic;

public interface ITopicDao {
//add a method , to add new topic
	String addNewTopic(Topic topic);
}

package dao;

import pojos.User;

public interface IUserDao {
	
	//add a e method for user registration(signup)
	String registerUser(User user);
	//add a method to link 1 role to the user
	String assignNewRole(long userId,long roleId);

}

package dao;

import java.util.Set;

import pojos.RoleEntity;
import pojos.RoleEnum;

public interface IRoleDao {
	String addRole(RoleEntity role);
	//add a method to get Set<RoleEntity> for specified Set<RoleEnum>
	Set<RoleEntity> getRolesByRoleName(Set<RoleEnum> roles);
}

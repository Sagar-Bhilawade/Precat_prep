package tester;

import static utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.TopicDaoImpl;
import dao.TutorialDaoImpl;
import dao.UserDaoImpl;
import pojos.RoleEnum;
import pojos.Topic;
import pojos.Tutorial;
import pojos.User;
import static java.time.LocalDate.parse;
import static pojos.RoleEnum.*;

public class GetAllTutorialDetailsWithTopicAndAuthor {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory()) {
			TutorialDaoImpl tutDao = new TutorialDaoImpl();
			System.out.println("Tut n Author n Topic details");
			tutDao.getAllTutorials().forEach(tut -> {
				System.out.println("Tut details " + tut);
				System.out.println("Author details "+tut.getAuthor());
				System.out.println("Topic Details "+tut.getSelectedTopic());
			});

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

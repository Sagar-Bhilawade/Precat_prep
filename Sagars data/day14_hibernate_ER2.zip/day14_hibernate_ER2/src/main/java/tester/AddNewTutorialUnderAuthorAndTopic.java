package tester;

import static utils.HibernateUtils.getFactory;

import java.time.LocalDate;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.TopicDaoImpl;
import dao.TutorialDaoImpl;
import dao.UserDaoImpl;
import pojos.RoleEnum;
import pojos.Topic;
import pojos.Tutorial;
import pojos.User;
import static java.time.LocalDate.parse;
import static pojos.RoleEnum.*;

public class AddNewTutorialUnderAuthorAndTopic {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			TutorialDaoImpl tutDao=new TutorialDaoImpl();
			System.out.println("Enter new tut  details : tutName,  publishDate,  visits  ");
			Tutorial tutorial=new Tutorial(sc.nextLine(), parse(sc.next()),sc.nextInt());
			sc.nextLine();
			System.out.println("Enter tut contents");
			tutorial.setContents(sc.nextLine());
			System.out.println("Enter author id n topic id");
			System.out.println(tutDao.addNewTutorialByAuthorAndTopic(tutorial, sc.nextLong(), sc.nextLong()));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

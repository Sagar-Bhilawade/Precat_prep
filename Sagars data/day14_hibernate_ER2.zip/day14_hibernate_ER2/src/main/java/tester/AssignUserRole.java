package tester;

import static utils.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.AddressDaoImpl;
import dao.UserDaoImpl;
import pojos.Address;

public class AssignUserRole {

	public static void main(String[] args) {
		try(SessionFactory sf=getFactory();Scanner sc=new Scanner(System.in))
		{
			UserDaoImpl userDao=new UserDaoImpl();
			System.out.println("Enter user id n role id");
			System.out.println(userDao.assignNewRole(sc.nextLong(),sc.nextLong()));
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "topics_tbl")
public class Topic extends BaseEntity {
	@Column(name = "topic_name", length = 30, unique = true)
	private String topicName;
	@Column(name = "topic_desc", length = 100)
	private String description;
	// bi dir one---many relationship : Topic 1 <-----> * Tutorial
	@OneToMany(mappedBy = "selectedTopic", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Tutorial> tutorials = new ArrayList<>();

	public Topic() {
		// TODO Auto-generated constructor stub
	}

	public Topic(String topicName, String description) {
		super();
		this.topicName = topicName;
		this.description = description;
	}

	// getters n setters
	public String getTopicName() {
		return topicName;
	}

	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Tutorial> getTutorials() {
		return tutorials;
	}

	public void setTutorials(List<Tutorial> tutorials) {
		this.tutorials = tutorials;
	}
	//as per Gavin King's reco : add helper method to establish bi dir relationship bet entities
	public void addTutorial(Tutorial tutorial)
	{
		//topic ---> tutorial
		tutorials.add(tutorial);
		//reverse link : tutorial ---> topic : IMPORTANT : o.w FK may be null!!!!!!!!!!!!!!!!!!!!!!11
		tutorial.setSelectedTopic(this);
		
	}
	//as per Gavin King's reco : add helper method to remove  bi dir relationship bet entities
		public void removeTutorial(Tutorial tutorial)
		{
			//topic ---> tutorial
			tutorials.remove(tutorial);
			//reverse link : tutorial ---> topic : IMPORTANT : o.w FK may be null!!!!!!!!!!!!!!!!!!!!!!11
			tutorial.setSelectedTopic(null);
			
		}

	@Override
	public String toString() {
		return "Topic ID " + getId() + " [topicName=" + topicName + ", description=" + description + "]";
	}

}

package pojos;
// passport number , creation date , location, expiry date ,issuing  country 

import java.time.LocalDate;
import javax.persistence.*;

@Embeddable // MANDATORY cls level annotation to tell hibernate , following is a composite
			// value type , which DOES NOT have stand alone existence
//depends upon the ownig entity : for id n life cycle
public class Passport {
	@Column(name = "passport_number", length = 20)
	private String passportNumber;
	@Column(name = "creation_date")
	private LocalDate creationDate;
	@Column(name = "expiry_date")
	private LocalDate expiryDate;
	@Column(length = 20)
	private String location;
	@Column(length = 20)
	private String country;

	public Passport() {
		// TODO Auto-generated constructor stub
	}

	public Passport(String passportNumber, LocalDate creationDate, LocalDate expiryDate, String location,
			String country) {
		super();
		this.passportNumber = passportNumber;
		this.creationDate = creationDate;
		this.expiryDate = expiryDate;
		this.location = location;
		this.country = country;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public LocalDate getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "Passport [passportNumber=" + passportNumber + ", creationDate=" + creationDate + ", expiryDate="
				+ expiryDate + ", location=" + location + ", country=" + country + "]";
	}

}

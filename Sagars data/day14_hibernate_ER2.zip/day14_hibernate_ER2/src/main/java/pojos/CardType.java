package pojos;

public enum CardType {
	CREDIT, DEBIT, FOREX
}

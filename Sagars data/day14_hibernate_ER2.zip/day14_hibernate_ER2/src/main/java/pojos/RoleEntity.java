package pojos;
import java.util.Objects;

import javax.persistence.*;

@Entity
@Table(name="roles")
public class RoleEntity extends BaseEntity {
	@Enumerated(EnumType.STRING)
	@Column(name="role_name",length = 20,unique = true)	
	private RoleEnum roleName;

	public RoleEntity() {
		// TODO Auto-generated constructor stub
	}

	public RoleEntity(RoleEnum roleName) {
		super();
		this.roleName = roleName;
	}

	public RoleEnum getRoleName() {
		return roleName;
	}

	public void setRoleName(RoleEnum roleName) {
		this.roleName = roleName;
	}

	@Override
	public String toString() {
		return "RoleEntity ID  "+getId()+" [roleName=" + roleName + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((roleName == null) ? 0 : roleName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoleEntity other = (RoleEntity) obj;
		if (roleName != other.roleName)
			return false;
		return true;
	}

	
	
	

}

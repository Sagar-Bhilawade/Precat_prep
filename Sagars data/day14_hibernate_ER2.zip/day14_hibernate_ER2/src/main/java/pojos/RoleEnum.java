package pojos;

public enum RoleEnum {
	CUSTOMER, AUTHOR, ADMIN
}

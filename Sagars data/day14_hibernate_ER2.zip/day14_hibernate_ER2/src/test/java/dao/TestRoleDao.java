package dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import pojos.RoleEntity;
import pojos.RoleEnum;
import utils.HibernateUtils;

class TestRoleDao {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		HibernateUtils.getFactory();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		HibernateUtils.getFactory().close();
	}

	@Test
	void testAddAdmin() {
		//test insertion of admin roles
		RoleDaoImpl dao=new RoleDaoImpl();
		String mesg = dao.addRole(new RoleEntity(RoleEnum.ADMIN));
		assertEquals(true, mesg.contains("Added"));
	}
	@Test
	void testAddAuthor() {
		//test insertion of author roles
		RoleDaoImpl dao=new RoleDaoImpl();
		String mesg = dao.addRole(new RoleEntity(RoleEnum.AUTHOR));
		assertEquals(true, mesg.contains("Added"));
	}
	@Test
	void testAddCustomer() {
		//test insertion of customer roles
		RoleDaoImpl dao=new RoleDaoImpl();
		String mesg = dao.addRole(new RoleEntity(RoleEnum.CUSTOMER));
		assertEquals(true, mesg.contains("Added"));
	}
	@Test
	void testGetRolesByRoleName()
	{
		RoleDaoImpl dao=new RoleDaoImpl();
		Set<RoleEntity> set = dao.getRolesByRoleName(Set.of(RoleEnum.ADMIN,RoleEnum.AUTHOR));
		System.out.println(set);
		assertEquals(2, set.size());
	}

}

package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.TutorialRepository;

@Service
@Transactional
public class TutorialServiceImpl implements ITutorialService {
	//dep : tut repo
	@Autowired
	private TutorialRepository tutRepo;

	@Override
	public List<String> getTutNamesByTopic(long topicId) {
		// TODO Auto-generated method stub
		return tutRepo.findTutNamesByTopicId(topicId);
	}

}

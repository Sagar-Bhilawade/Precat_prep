package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.dao.TopicRepository;
import com.app.service.ITutorialService;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	//dep : Topic dao i/f (since service layer is skipped!!!!!!!!!!!!!)
	@Autowired
	private TopicRepository topicDao;
	//dep : tut service i/f
	@Autowired
	private ITutorialService tutService;
	 
	public CustomerController() {
		System.out.println("in ctor of "+getClass());
	}
	//add req handling method to forward the clnt to topics page.
	@GetMapping("/topics")
	public String showTopics(Model map)
	{
		System.out.println("in show topics "+map);
		//add model attri : topic list
		map.addAttribute("topic_list", topicDao.findAll());
		return "/customer/topics";//D.S --> V.R ---> AVN : /WEB-INF/views/customer/topics.jsp
	}
	//add a req handling method : to get all tuts under chosen topic
	//http://localhost:8080/day18_boot_cms/customer/tutorials?topicId=2
	@GetMapping("/tutorials")
	public String getTutorialsByTopic(@RequestParam long topicId,Model map) //String --> long automatically done  by SC ---> WC
	{
		System.out.println("in get tuts "+topicId+" "+map);
		map.addAttribute("tut_names",tutService.getTutNamesByTopic(topicId));
		return "/customer/tutorials";//LVN ---> D.S --> V.R ---> AVN : /WEB-INF/views/customer/tutorials
	}

}

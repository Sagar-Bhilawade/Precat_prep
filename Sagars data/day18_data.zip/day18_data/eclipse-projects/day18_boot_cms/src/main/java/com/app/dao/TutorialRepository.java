package com.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.app.pojos.Tutorial;

public interface TutorialRepository extends JpaRepository<Tutorial, Long> {
//add a method to get all tutorial for specified topic id  
//	List<Tutorial> findByTopicId(long topicId);
	// select t from Tutorial t where t.selectedTopic.id=:id => cross join
	// List<Tutorial> findBySelectedTopicId(long topicId);
	// custom query method : to get tut names for the specified topic id n using
	// inner join : can be ANY method name : DO NOT need to stick to finder method
	// pattern
	@Query("select t.tutName from Tutorial t join t.selectedTopic tp where tp.id=?1")
	List<String> findTutNamesByTopicId(long topicId);

	// add a method to get tutorial's (updated visit count wise) details by it's
	// name
	// Tutorial findByTutorialName(String tutName);
	Optional<Tutorial> findByTutName(String tutorialName);

	// under admin role , add a method to insert new tut contents
//	String addNewTutorial(Tutorial newTut); => will be repalced bu inherited API : public T save(T entity)

}

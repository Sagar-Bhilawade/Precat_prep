package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import static utils.DBUtils.*;

import dao.TopicDaoImpl;
import dao.TutorialDaoImpl;
import dao.UserDaoImpl;
import pojos.Role;
import pojos.User;

/**
 * Servlet implementation class LoginServlet
 */

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;
	private TopicDaoImpl topicDao;
	private TutorialDaoImpl tutDao;

	// def ctor
	public LoginServlet() {
		System.out.println("in def ctor of " + getClass() + " servlet config " + getServletConfig());// null
	//	System.out.println("servlet ctx "+getServletContext());//NPExc
	}

	// parameterized ctor
	public LoginServlet(String mesg) {
		System.out.println("in parameterized ctor of " + getClass() + " servlet config " + getServletConfig());// DOES
																												// NOT
																												// get
																												// called
																												// !!!!!!!!!!
	}

	/**
	 * @see Servlet#init()
	 */
	@Override
	public void init() throws ServletException {
		ServletConfig config = getServletConfig();
		System.out.println("in init of " + getClass() + " servlet config " + config);// not null
		System.out.println("ctx "+getServletContext());//not null 
		// create user dao instance
		try {
			// open db connection
			openConnection(config.getInitParameter("url"), config.getInitParameter("user_name"),
					config.getInitParameter("password"));
			userDao = new UserDaoImpl();
			topicDao = new TopicDaoImpl();
			tutDao = new TutorialDaoImpl();
		} catch (Exception e) {
			// ServletException(String mesg,Throwable rootCause)
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			userDao.cleanUp();
			topicDao.cleanUp();
			tutDao.cleanUp();
			closeConnection();
		} catch (Exception e) {
			// report the err to WC : RuntimeExc : OPTIONAL BUT rec.
			throw new RuntimeException("err in destroy of " + getClass(), e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. set cont type
		response.setContentType("text/html");
		// 2 get PW
		try (PrintWriter pw = response.getWriter()) {
			// 3. read request params : req processing
			String email = request.getParameter("em");
			String password = request.getParameter("pass");
			// 4. invoke dao's method for authentication
			User user = userDao.authenticateUser(email, password);
			if (user == null) // => invalid login
				pw.print("<h5> Invalid Credentials , Please <a href='login.html'>Retry</a></h5>");
			else // => login success i.e authentication success
			{
				// 1. Get HttpSession from WC
				// API of HttpServletRequest : public HttpSession getSession()
				HttpSession session = request.getSession();
				System.out.println("HttpSession " + session.getClass());// impl class name from server specific jar(eg :
																		// catalina.jar)
				System.out.println("from login servlet is session new " + session.isNew());// true
				System.out.println("Session ID " + session.getId());// server specific session id creation
				// save validated user details in HttpSession
				// API of HttpSession : public void setAttribute(String attrName,Object
				// attrValue)
				session.setAttribute("user_details", user);
				// add dao instances under session scope
				session.setAttribute("user_dao", userDao);
				session.setAttribute("topic_dao", topicDao);
				session.setAttribute("tut_dao", tutDao);
				// In case of successful login redirect the clnt to next page in the NEXT
				// request
				// HttpServletResponse : public void sendRedirect(String redirectLoc) throws
				// IOExc
				if (user.getUserRole() == Role.ADMIN) // role based authorization
					response.sendRedirect("admin");
				else // => customer successful login
					response.sendRedirect("topics");
				// Internals : WC sends temp redirect resp : SC 302 | location=topics ,
				// Set-Cookie : user_details : user's tostring | body : EMPTY
				// clnt browser --> sends NEW request : http://host:port/day5.1/topics , method
				// : GET

			}

		} catch (Exception e) {
			// re throw the exc to the caller(WC) , by wrapping it in ServletExc
			throw new ServletException("err in do-post " + getClass(), e);
		}
	}

}

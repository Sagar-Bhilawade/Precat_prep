package dao;

import java.sql.SQLException;
import java.util.List;

import pojos.Topic;

public interface ITopicDao {
//add a method to get all available topics
	List<Topic> getAllTopics() throws SQLException;
}

package pojos;

public enum Role {
	ADMIN, CUSTOMER
}

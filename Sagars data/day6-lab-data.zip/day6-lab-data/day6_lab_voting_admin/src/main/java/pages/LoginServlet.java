package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import static utils.DBUtils.*;

import dao.UserDaoImpl;
import pojos.User;

/**
 * Servlet implementation class LoginServlet
 */
//eager
@WebServlet(value = "/signin",loadOnStartup = 1)
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;

	/**
	 * @see Servlet#init()
	 */
	// Overriding form of the method CAN NOT add any NEW or BROADER CHECKED excs
	@Override
	public void init() throws ServletException {
		try {
			// open cn
			openConnection();
			// create user (voter+admin) dao
			userDao = new UserDaoImpl();
		} catch (Exception e) {
			throw new ServletException("err in init of " + getClass(), e);
		}
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		try {
			// dao clean up
			if (userDao != null)
				userDao.cleanUp();
			// close cn
			closeConnection();
		} catch (Exception e) {
			// System.out.println("err in destroy "+e);
			throw new RuntimeException("err in destroy of " + getClass(), e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. set resp cont type
		response.setContentType("text/html");
		// 2. get PW
		try (PrintWriter pw = response.getWriter()) {
			// 3. get user name n pwd from req params
			String userName = request.getParameter("nm");
			String password = request.getParameter("pass");
			// 4. invoke dao's method : user 's authentication(signin)
			User user = userDao.authenticateUser(userName, password);
			// chk for success or failure
			if (user == null) // => failure in signin
				pw.print("<h4> Invalid Name or Password , Please <a href='login.html'>Retry</a></h4>");
			else {
				// => login success
				// 4. get HttpSession from WC
				HttpSession session = request.getSession();
				// 5. store details : validated user details n user dao , under the session
				// scope
				// public void setAttribute(String attrName,Object attrVal)
				session.setAttribute("user_dtls", user);
				session.setAttribute("user_dao", userDao);
				// 6. perform role based authorization
				// in case of admin --> redirect --> "admin" or voter ---> status : false --->
				// candidate_list or status page
				if (user.getRole().equals("admin"))
					response.sendRedirect("admin");
				else // voter login
				if (user.isStatus()) // voter has already voted
					response.sendRedirect("status");
				else // voter : not yet voted
					response.sendRedirect("candidate_list");

			}

		} catch (Exception e) {
			throw new ServletException("err in do-post of " + getClass(), e);
		}
	}

}

package dao;

import static utils.DBUtils.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import pojos.Candidate;

public class CandidateDaoImpl implements ICandidateDao {
	// state
	private Connection cn;
	private PreparedStatement pst1, pst2;

	// add def ctor
	public CandidateDaoImpl() throws SQLException {
		// get existing cn from db utils
		cn = getConnection();
		// pst1 : top 2
		pst1 = cn.prepareStatement("select * from candidates order by votes desc limit 2");
		// pst2 : grp by
		pst2 = cn.prepareStatement("select party,sum(votes) from candidates group by party");
		System.out.println("candidate dao created...");
	}

	@Override
	public List<Candidate> getTop2ByVotes() throws SQLException {
		List<Candidate> candidates = new ArrayList<>();
		try (ResultSet rst = pst1.executeQuery()) {
			while (rst.next())
				candidates.add(new Candidate(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getInt(4)));

		}
		return candidates;
	}

	@Override
	public LinkedHashMap<String, Integer> partywiseVotesAnalysis() throws SQLException {
		LinkedHashMap<String, Integer> map=new LinkedHashMap<>();
		try(ResultSet rst=pst2.executeQuery())
		{
			while(rst.next())
				map.put(rst.getString(1), rst.getInt(2));				
		}
		return map;
	}

	// clean up
	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		if (pst2 != null)
			pst2.close();
		System.out.println("candidate dao cleaned up!");
	}

}

package dao;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

import pojos.Candidate;

public interface ICandidateDao {
	//get top 2 candidates
	List<Candidate> getTop2ByVotes() throws SQLException;
	//party wise votes analysis
	LinkedHashMap<String,Integer> partywiseVotesAnalysis() throws SQLException;

}

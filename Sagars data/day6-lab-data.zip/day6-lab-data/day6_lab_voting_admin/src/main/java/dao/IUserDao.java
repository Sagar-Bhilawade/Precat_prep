package dao;

import java.sql.SQLException;

import pojos.User;

public interface IUserDao {
//add a method for voter/admin signin
	User authenticateUser(String name,String password) throws SQLException;
}

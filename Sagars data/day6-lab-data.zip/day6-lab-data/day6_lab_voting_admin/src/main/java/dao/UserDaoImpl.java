package dao;

import static utils.DBUtils.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import pojos.User;

public class UserDaoImpl implements IUserDao {
	// state
	private Connection cn;
	private PreparedStatement pst1;

	public UserDaoImpl() throws SQLException {
		// get cn from DBUtils
		cn = getConnection();
		// pst1 : signin
		pst1 = cn.prepareStatement("select * from voters where name=? and password=?");
		System.out.println("user dao created....");
	}

	@Override
	public User authenticateUser(String name, String password) throws SQLException {
		// set IN params
		pst1.setString(1, name);
		pst1.setString(2, password);
		// exec Query ---> RST --> process RST --> User or null
		try (ResultSet rst = pst1.executeQuery()) {
			// int userid, String name, String email, String password, boolean status,
			// String role
			if (rst.next())
				return new User(rst.getInt(1), name, rst.getString(3), 
						password, rst.getBoolean(5), rst.getString(6));
		}
		return null;
	}

	// clean up
	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		System.out.println("user dao cleaned up!");
	}

}

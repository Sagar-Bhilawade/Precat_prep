package com.app.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ApiResponse;
import com.app.dto.EmployeeDTO;
import com.app.dto.LoginRequestDTO;
import com.app.entities.Employee;
import com.app.service.IEmployeeService;

@RestController // =@Controller + @ResponseBody
@RequestMapping("/api/employees") // resource : class level pattern
@CrossOrigin(origins = "http://localhost:3000")
@Validated // added for enabling validation support for req params n path vars
public class EmployeeController {
	// dep : service layer i/f
	@Autowired
	private IEmployeeService empService;

	public EmployeeController() {
		System.out.println("in ctor of " + getClass());
	}

	// add req handling method(REST API endpoint) to ret list of all emps
	@GetMapping
	public List<Employee> fetchAllEmpDetails() {
		System.out.println("in fetch all ");
		return empService.getAllEmployees();

	}

	// add req handling method(REST API endpoint) to create a new resource : Emp
	@PostMapping
	public ResponseEntity<?> addNewEmp(@RequestBody @Valid Employee emp) {
		try {
			System.out.println("in add new emp " + emp.getId());// id : null
			return ResponseEntity.status(HttpStatus.CREATED).body(empService.insertEmpDetails(emp));
		} catch (RuntimeException e) {
			System.out.println("in add new emp err " + e);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(e.getMessage()));
		}

	}

	// add req handling method(REST API endpoint) to delete emp details
	@DeleteMapping("/{eid}")
	public String deleteEmpDetails(@PathVariable @Valid @NotNull @Range(min = 1, max = 100) long eid) {
		System.out.println("in del emp dtls " + eid);
		return empService.deleteEmpDetails(eid);
	}

	// add req handling method(REST API endpoint) to get emp details by it's id
	@GetMapping("/{empId}")
	public ResponseEntity<?> getEmpDetails(
			@PathVariable @Valid @Range(min = 1, max = 100, message = "Emp id must be within 1-100") long empId) {
		System.out.println("in get emp dtls");
//		try {
		// o.s.http.ResponseEntity(T body,HttpStatus stsCode)
		return new ResponseEntity<>(empService.getEmpDetails(empId), HttpStatus.OK);
//		} catch (RuntimeException e) {
//			System.out.println("err in emp controller " + e);
//			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);
//		}
	}

	// add req handling method(REST API endpoint) to update emp details
	@PutMapping
	public Employee updateEmpDetails(@RequestBody Employee emp) {
		System.out.println("in update  emp dtls" + emp);// not null id
		return empService.updateEmpDetails(emp);
	}

	// add req handling method(REST API endpoint) to authenticate(signin) emp
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateEmp(@RequestBody @Valid LoginRequestDTO request) {
		System.out.println("in auth emp "+request);
		return ResponseEntity.ok().body(empService.authenticateEmployee(request));
	}

}

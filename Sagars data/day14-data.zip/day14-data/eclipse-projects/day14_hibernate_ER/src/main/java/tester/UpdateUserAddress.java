package tester;

import static utils.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.AddressDaoImpl;
import pojos.Address;
import pojos.User;

public class UpdateUserAddress {

	public static void main(String[] args) {
		try(SessionFactory sf=getFactory();Scanner sc=new Scanner(System.in))
		{
			//create dao instance
			AddressDaoImpl adrDao=new AddressDaoImpl();
			System.out.println("Enter user id");
			long userId=sc.nextLong();
			sc.nextLine();
			System.out.println("Enter new adr details : line1, line2,  city,  state,  country zipCode");
			Address adr=new Address(sc.nextLine(), sc.nextLine(), sc.next(), sc.next(), sc.next(), sc.next());
			System.out.println(adrDao.updateUserAddress(userId, adr));
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}

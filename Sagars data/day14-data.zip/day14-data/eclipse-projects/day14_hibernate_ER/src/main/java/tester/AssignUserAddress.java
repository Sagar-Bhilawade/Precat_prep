package tester;

import static utils.HibernateUtils.getFactory;

import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.AddressDaoImpl;
import pojos.Address;

public class AssignUserAddress {

	public static void main(String[] args) {
		try(SessionFactory sf=getFactory();Scanner sc=new Scanner(System.in))
		{
			//create dao instance
			AddressDaoImpl adrDao=new AddressDaoImpl();
			System.out.println("Enter user's email");
			String email=sc.next();
			sc.nextLine();
			System.out.println("Enter adr details : line1, line2,  city,  state,  country zipCode");
			Address adr=new Address(sc.nextLine(), sc.nextLine(), sc.next(), sc.next(), sc.next(), sc.next());
			System.out.println(adrDao.assignUserAddress(email, adr));
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}

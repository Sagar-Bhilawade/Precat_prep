package dao;

import static utils.HibernateUtils.getFactory;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Address;
import pojos.User;

public class AddressDaoImpl implements IAddressDao {

	@Override
	public String assignUserAddress(String email, Address address) {
		String jpql = "select u from User u where u.email=:em";
		String mesg = "Assigning address failed !!!!!!!!!!!!!";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin a tx
		Transaction tx = session.beginTransaction();
		try {
			// 1 . get user details using it's email
			User user = session.createQuery(jpql, User.class).setParameter("em", email).getSingleResult();
			// => email valid , user : PERSISTENT
			//2. establish uni dir relationship : Address ---> User
			address.setOwner(user);
			//3. persist the address
			session.persist(address);			
			tx.commit();
			mesg="Address assigned successfully for User with first Name "+user.getFirstName();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

	@Override
	public String updateUserAddress(long userId, Address updatedAddress) {
		String mesg="Address updation failed !!!!!!!!!";
		// get session from SF
				Session session=getFactory().getCurrentSession();
				//begin a tx
				Transaction tx=session.beginTransaction();
				try {
					
					//user Id ---same as address id ? YES
					//confirm if addr exists 
					Address address=session.get(Address.class, userId);
					//address : PERSISTENT
					if(address != null)
					{
						//adr exists 
						//address : existing
						//updatedAdr : new adr
						//assign existing adr id to the new adr
						updatedAddress.setId(userId);//updatedAddress : DETACHED
						//saveOrUpdate or update : exc : NonUniqueObjExc : Lab work 
						session.merge(updatedAddress);
						mesg="Updated address for user with id="+userId;
					}					
					tx.commit();//DML : update
				} catch (RuntimeException e) {
					if(tx != null)
						tx.rollback();
					throw e;
				}
		return mesg;
	}
	

}

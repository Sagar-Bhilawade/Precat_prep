package dao;

import pojos.User;

public interface IUserDao {
	
	//add a e method for user registration(signup)
	String registerUser(User user);

}

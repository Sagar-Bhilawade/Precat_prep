package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import pojos.Topic;
import static utils.HibernateUtils.getFactory;

public class TopicDaoImpl implements ITopicDao {

	@Override
	public String addNewTopic(Topic topic) {
		String mesg="Adding topic failed !!!!!!!!!!";
		// get session from SF
				Session session=getFactory().getCurrentSession();
				//begin a tx
				Transaction tx=session.beginTransaction();
				try {
					
					session.persist(topic);
					tx.commit();
					mesg="Added new topic with ID = "+topic.getId();
				} catch (RuntimeException e) {
					if(tx != null)
						tx.rollback();
					throw e;
				}
		return mesg;
	}

}

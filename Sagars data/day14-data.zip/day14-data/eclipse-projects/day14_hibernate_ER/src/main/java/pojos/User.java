package pojos;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "users_tbl")
public class User extends BaseEntity {
	@Column(length = 20, name = "first_name")
	private String firstName;
	@Column(length = 20, name = "last_name")
	private String lastName;
	@Column(length = 20, unique = true)
	private String email;
	@Column(length = 20, nullable = false)
	private String password;
	@Column(nullable = false)
	private LocalDate dob;
	// many to many relationship between User *----->* Role :Entity
	@ManyToMany // MANDATORY : o.w hib throws MappingExc . In this case hib will decide the name
				// of the join table
	// Can you specify name of the link table ?YES
	// owning side n inverse side in case of many-to-many
	// The side containing link table def : owning
	// The side NOT containing link table def : non owning(inverse)
	@JoinTable(name = "users_roles", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
	private Set<RoleEntity> roles = new HashSet<>();// as per Gavin King's suggestion : DO NOT leave collection ased
													// property def inited.
	// uni dir Association between entity n composite value type User 1----->1
	// Passport
	@Embedded // OPTIONAL , to be used for understanding purpose only !!!
	private Passport passport;
	// uni dir Association between entity n collection of composite value type :
	// User 1----->* Card
	@ElementCollection // MANDATORY : o.w hib throws MappingExc
	@CollectionTable(name = "user_cards", joinColumns = @JoinColumn(name = "user_id")) // OPTIONAL to specify name of
																						// the coll table + FK col name
	private List<Card> cards = new ArrayList<>();
	// collection of BASIC value types User 1---->* Hobbies
	@ElementCollection
	@CollectionTable(name = "user_hobbies", joinColumns = @JoinColumn(name = "user_id"))
	@Column(name="hobby")
	private List<String> hobbies = new ArrayList<>();

	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(String firstName, String lastName, String email, String password, LocalDate dob) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.dob = dob;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Set<RoleEntity> getRoles() {
		return roles;
	}

	public void setRoles(Set<RoleEntity> roles) {
		this.roles = roles;
	}

	public Passport getPassport() {
		return passport;
	}

	public void setPassport(Passport passport) {
		this.passport = passport;
	}

	public List<Card> getCards() {
		return cards;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	public List<String> getHobbies() {
		return hobbies;
	}

	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}

	@Override
	public String toString() {
		return "User ID " + getId() + " [firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", password=" + password + ", dob=" + dob + "]";
	}

	// add helper methods : for simpler clean coding in DAO layer
	// add 2 methods : add role n remove role
	public void addRole(RoleEntity role) {
		roles.add(role);
	}

	public void removeRole(RoleEntity role) {
		roles.remove(role);
	}
}

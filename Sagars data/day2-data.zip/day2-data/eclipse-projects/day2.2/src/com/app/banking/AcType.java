package com.app.banking;

public enum AcType {
	SAVING, CURRENT, FD, DMAT, LOAN
}
